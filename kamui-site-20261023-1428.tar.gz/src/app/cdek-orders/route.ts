/**
 * /cdek-orders?token=<PAYMENTS_TEST_TOKEN> — служебная страница для продавца:
 * оплаченные заказы сайта и их накладные СДЭК.
 *
 * Если у оплаченного заказа нет накладной (сервер перезапустился в момент оплаты, СДЭК был недоступен
 * или не принял данные) — кнопка «Создать накладную». Если СДЭК отказал, видна причина.
 * Кнопка «Записать трек-номера в таблицу» дописывает номера СДЭК в колонку «Доставка» — и тем заказам,
 * у которых номер появился позже, чем сайт его ждал.
 * Письма покупателям (оплата, трек-номер, срок хранения) отправляет сам сайт — src/lib/mail; здесь видно, какие ушли,
 * и есть кнопка «Проверить и отправить письма покупателям».
 * Кроме оплат ЮKassa показываются оплаченные заказы из таблицы с пунктом выдачи СДЭК — в том числе заказы
 * из-за рубежа (Robokassa). Для этого нужен скрипт таблицы с действием paidOrders (apps-script.gs).
 * Без правильного токена отвечает 404. В поиск не попадает.
 */
import { features } from "@/config/features";
import { AT_PICKUP_CODES, CdekOrderRejected, findShipment, getTrackingNumber } from "@/lib/delivery/cdek";
import { shipPaidOrder, type ShipResult } from "@/lib/delivery/ship";
import { runMailJobs, storageUntil } from "@/lib/mail/jobs";
import { smtpConfig } from "@/lib/mail/smtp";
import { updateOrderStrict } from "@/lib/orders/store";
import { fetchPaidOrdersFromSheet, type SheetPaidOrder } from "@/lib/orders/stores/google-sheets";
import { listPaidSiteOrders, type YooKassaPayment } from "@/lib/payments/yookassa";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = {
  "Content-Type": "text/html; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Robots-Tag": "noindex, nofollow",
  "Referrer-Policy": "no-referrer",
};

const notFound = () => new Response("Not found", { status: 404, headers: { "X-Robots-Tag": "noindex" } });

function authorized(given: string | null | undefined): boolean {
  const token = process.env.PAYMENTS_TEST_TOKEN ?? "";
  return token.length >= 8 && given === token;
}

type CdekState =
  | { kind: "ok"; number: string | null; status?: string; statusCode?: string; arrivedAt?: string; keepFreeUntil?: string }
  | { kind: "none" }
  | { kind: "rejected"; reason: string }
  | { kind: "error"; reason: string };

async function cdekState(orderId: string): Promise<CdekState> {
  try {
    const s = await findShipment(orderId);
    if (!s) return { kind: "none" };
    const extra = { status: s.status, statusCode: s.statusCode, arrivedAt: s.arrivedAt, keepFreeUntil: s.keepFreeUntil };
    if (s.trackingNumber) return { kind: "ok", number: s.trackingNumber, ...extra };
    try {
      return { kind: "ok", number: await getTrackingNumber(s.uuid), ...extra };
    } catch (err) {
      if (err instanceof CdekOrderRejected) return { kind: "rejected", reason: err.message };
      throw err;
    }
  } catch (err) {
    return { kind: "error", reason: String((err as Error).message).slice(0, 200) };
  }
}

/** Проверяем накладные небольшими пачками, чтобы не упереться в лимиты СДЭК */
async function statesFor(payments: Item[]): Promise<CdekState[]> {
  const out: CdekState[] = [];
  for (let i = 0; i < payments.length; i += 6) {
    out.push(...(await Promise.all(payments.slice(i, i + 6).map((p) => cdekState(p.metadata?.orderId ?? "")))));
  }
  return out;
}

/** Заказ на странице: платёж ЮKassa или (fromSheet) оплаченный заказ из таблицы — например, из-за рубежа через Robokassa */
type Item = YooKassaPayment & { fromSheet?: boolean; place?: string; /** отметки о письмах покупателю из таблицы */ marks?: string };

/** Строка таблицы → тот же вид, что у платежа ЮKassa (данные для карточки — в metadata) */
function sheetItem(o: SheetPaidOrder): Item | null {
  const pvz = /^СДЭК ПВЗ\s+([A-Za-z0-9_-]+)/.exec(o.delivery)?.[1];
  if (!pvz || !o.id) return null;
  const kit = /^Подарочный набор/.test(o.comment) ? /наклейка JOS\s+(\S+)/.exec(o.comment)?.[1] : undefined;
  return {
    id: `sheet-${o.id}`,
    status: "succeeded",
    paid: true,
    amount: { value: String(o.total), currency: "RUB" },
    created_at: o.createdAt || new Date().toISOString(),
    metadata: {
      orderId: o.id,
      pvz,
      name: o.name,
      phone: o.phone,
      qty: String(o.quantity),
      delivery: o.delivery.replace(/ · трек \d+.*$/, ""),
      ...(kit ? { kit } : {}),
    },
    fromSheet: true,
    place: o.city,
    marks: o.mailMarks,
  };
}

/** Оплаты ЮKassa + оплаченные заказы из таблицы, которых нет в ЮKassa (Robokassa, ручные), — новые сверху */
async function loadItems(days: number): Promise<{ items: Item[]; note?: string }> {
  const [yk, sheet] = await Promise.allSettled([listPaidSiteOrders(days), fetchPaidOrdersFromSheet(days)]);
  if (yk.status === "rejected") throw yk.reason;
  const items: Item[] = [...yk.value];
  let note: string | undefined;
  if (sheet.status === "rejected") note = `Заказы из таблицы не загрузились: ${String((sheet.reason as Error)?.message ?? sheet.reason).slice(0, 160)}`;
  else if (sheet.value === null)
    note = "Заказы из-за рубежа (Robokassa) здесь не видны: обновите основной скрипт таблицы и разверните новую версию.";
  else {
    const known = new Set(items.map((p) => p.metadata?.orderId));
    const marks = new Map(sheet.value.map((o) => [o.id, o.mailMarks]));
    for (const p of items) p.marks = marks.get(p.metadata?.orderId ?? "");
    for (const o of sheet.value) {
      if (known.has(o.id)) continue;
      const it = sheetItem(o);
      if (it) items.push(it);
    }
  }
  items.sort((a, b) => String(b.captured_at ?? b.created_at).localeCompare(String(a.captured_at ?? a.created_at)));
  return { items, note };
}

const esc = (v: unknown) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

const when = (p: YooKassaPayment) =>
  new Date(p.captured_at ?? p.created_at).toLocaleString("ru-RU", {
    timeZone: "Europe/Moscow",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });

const rub = (v: string) => `${Math.round(Number(v)).toLocaleString("ru-RU")} ₽`;

function button(token: string, orderId: string, label: string) {
  return `<form method="post"><input type="hidden" name="token" value="${esc(token)}"><input type="hidden" name="order" value="${esc(orderId)}"><button type="submit">${esc(label)}</button></form>`;
}

/**
 * Посылка ещё не передана в СДЭК: накладной нет, СДЭК её отклонил или она только оформлена
 * (статус «Создан» / «Принят» — СДЭК ещё не получил посылку на складе).
 */
function notShipped(p: Item, s: CdekState): boolean {
  if (!p.metadata?.pvz) return false;
  if (s.kind === "none" || s.kind === "rejected") return true;
  if (s.kind !== "ok") return false;
  if (s.statusCode) return s.statusCode === "CREATED" || s.statusCode === "ACCEPTED";
  return !s.status || /^(создан|принят)$/i.test(s.status.trim());
}

function card(p: Item, s: CdekState, token: string, waiting = false): string {
  const m = p.metadata ?? {};
  const id = m.orderId ?? "";
  let cdek: string;
  let cls: string;
  if (!m.pvz) {
    cls = "warn";
    cdek = "Заказ без пункта выдачи СДЭК — отправку оформляет менеджер";
  } else if (s.kind === "ok") {
    cls = "ok";
    cdek = `✓ Накладная СДЭК${s.number ? ` № ${esc(s.number)}` : " создана, номер ещё присваивается"}${s.status ? ` · ${esc(s.status)}` : ""}`;
  } else if (s.kind === "none") {
    cls = "bad";
    cdek = p.fromSheet
      ? "⚠ Накладной нет — оформите отправление в личном кабинете СДЭК"
      : `⚠ Накладной нет${button(token, id, "Создать накладную")}`;
  } else if (s.kind === "rejected") {
    cls = "bad";
    cdek = p.fromSheet
      ? `✕ ${esc(s.reason)} — оформите отправление в личном кабинете СДЭК`
      : `✕ ${esc(s.reason)}${button(token, id, "Создать заново")}`;
  } else {
    cls = "warn";
    cdek = `Не удалось проверить в СДЭК: ${esc(s.reason)}`;
  }
  return `<article class="${cls}${waiting ? " wait" : ""}">
  <header><b>${esc(id)}</b><span>${esc(when(p))} · ${esc(rub(p.amount.value))}</span></header>
  <p class="who">${esc(m.name)} · ${esc(m.phone)} · ${m.kit ? `подарочный набор (JOS ${esc(m.kit)}) × ` : ""}${esc(m.qty)} шт.</p>
  ${p.fromSheet ? `<p class="tag">${esc(p.place || "из таблицы")}${/,/.test(p.place ?? "") ? " · из-за рубежа" : ""}</p>` : ""}
  ${m.delivery ? `<p class="dim">${esc(m.delivery)}</p>` : ""}
  <div class="cdek">${cdek}</div>
  ${storageLine(s)}${mailsLine(p.marks)}
</article>`;
}

function mailState(): string {
  const cfg = smtpConfig();
  return cfg
    ? `<p class="mailstate">Письма покупателям: <b>включены</b>, отправляются с ${esc(process.env.MAIL_FROM?.trim() || cfg.user)} — после оплаты, с трек-номером и за 2 дня до конца хранения.</p>`
    : `<p class="mailstate"><span class="off">Письма покупателям выключены</span>: в настройках сайта нет SMTP_USER и SMTP_PASSWORD.</p>`;
}

const ddmm = (d: Date) => d.toLocaleDateString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "2-digit" });

/** «Ждёт в пункте выдачи — хранение до 30.10» */
function storageLine(s: CdekState): string {
  if (s.kind !== "ok" || !AT_PICKUP_CODES.includes(String(s.statusCode))) return "";
  const until = storageUntil(s.arrivedAt, s.keepFreeUntil);
  if (!until) return `<p class="pick">Ждёт в пункте выдачи</p>`;
  const left = Math.ceil((until.getTime() - Date.now()) / 864e5);
  return `<p class="pick${left <= 2 ? " soon" : ""}">Ждёт в пункте выдачи — хранение до ${esc(ddmm(until))}${left >= 0 ? ` (осталось ${left} дн.)` : " (срок вышел)"}</p>`;
}

/** Какие письма покупателю уже ушли (по отметкам в таблице) */
function mailsLine(marks?: string): string {
  if (marks === undefined) return "";
  const has = (re: RegExp) => re.test(marks);
  const items = [
    has(/оплата/i) ? "✓ спасибо за заказ" : "",
    has(/трек/i) ? "✓ трек-номер" : "",
    has(/хранение/i) ? "✓ напоминание о хранении" : "",
  ].filter(Boolean);
  return `<p class="mails">Письма: ${items.length ? items.join(" · ") : "ещё не отправлялись"}</p>`;
}

function mailButton(token: string) {
  return `<form method="post" class="sync"><input type="hidden" name="token" value="${esc(token)}"><input type="hidden" name="action" value="mail"><button type="submit" class="alt">Проверить и отправить письма покупателям</button></form>`;
}

function syncButton(token: string) {
  return `<form method="post" class="sync"><input type="hidden" name="token" value="${esc(token)}"><input type="hidden" name="action" value="sync"><button type="submit">Записать трек-номера в таблицу</button></form>`;
}

/** Номера СДЭК → колонка «Доставка» таблицы (как пишет её сайт после оплаты: «… · трек 1234567890») */
async function syncTracks(days: number): Promise<{ ok: boolean; text: string }> {
  let payments: Item[];
  try {
    payments = (await loadItems(days)).items.filter((p) => p.metadata?.pvz && p.metadata?.orderId);
  } catch (err) {
    return { ok: false, text: `Не удалось получить платежи из ЮKassa: ${(err as Error).message}` };
  }
  const states = await statesFor(payments);
  let written = 0;
  const failed: string[] = [];
  for (let i = 0; i < payments.length; i++) {
    const s = states[i];
    if (s.kind !== "ok" || !s.number) continue;
    const m = payments[i].metadata!;
    const base = m.delivery || `СДЭК ПВЗ ${m.pvz}`;
    try {
      await updateOrderStrict(m.orderId!, {
        delivery: {
          provider: "cdek",
          label: `${base} · трек ${s.number}`,
          cdek: { pickupPointCode: m.pvz!, trackingNumber: s.number },
        },
      });
      written++;
    } catch {
      failed.push(m.orderId!);
    }
  }
  const noNumber = states.filter((s) => s.kind !== "ok" || !s.number).length;
  return {
    ok: failed.length === 0,
    text:
      `Трек-номера записаны в таблицу: ${written}.` +
      (noNumber ? ` Без номера СДЭК: ${noNumber}.` : "") +
      (failed.length ? ` Не удалось записать: ${failed.join(", ")}.` : ""),
  };
}

function page(body: string): Response {
  return new Response(
    `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>Накладные СДЭК</title>
<style>
:root{color-scheme:light dark;--bg:#f6f6f7;--card:#fff;--line:#e3e3e6;--dim:#6b6b73;--ok:#1d8a4e;--bad:#c62828;--warn:#9a6a00;--waitbg:#fff4c2}
@media (prefers-color-scheme:dark){:root{--bg:#111113;--card:#1b1b1e;--line:#2c2c31;--dim:#9a9aa3;--ok:#4cc38a;--bad:#ff6b6f;--warn:#e3b341;--waitbg:#3a3010}}
*{box-sizing:border-box}body{margin:0;padding:16px;background:var(--bg);font:15px/1.45 -apple-system,system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:720px;margin:0 auto}h1{font-size:22px;margin:4px 0 6px}.lead{color:var(--dim);margin:0 0 16px}
.msg{padding:12px 14px;border-radius:10px;margin:0 0 16px;font-weight:600}.msg.ok{background:rgba(29,138,78,.12);color:var(--ok)}.msg.bad{background:rgba(198,40,40,.12);color:var(--bad)}
article{background:var(--card);border:1px solid var(--line);border-left-width:4px;border-radius:10px;padding:12px 14px;margin:0 0 10px}
article.wait{background:var(--waitbg);border-color:var(--warn)}h2{font-size:17px;margin:22px 0 10px}h2 small{color:var(--dim);font-weight:400}
article.ok{border-left-color:var(--ok)}article.bad{border-left-color:var(--bad)}article.warn{border-left-color:var(--warn)}
header{display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px 12px}header span{color:var(--dim)}
p{margin:6px 0 0}.tag{display:inline-block;margin:6px 0 0;padding:2px 8px;border-radius:6px;background:rgba(0,0,0,.07);font-size:13px;font-weight:600}.dim{color:var(--dim);font-size:13px}.cdek{margin-top:8px;font-weight:600}
.pick{margin-top:6px;font-weight:600;color:var(--warn)}.pick.soon{color:var(--bad)}.mails{margin-top:6px;font-size:13px;color:var(--dim)}
.mailstate{margin:0 0 12px;font-size:14px}.mailstate b{color:var(--ok)}.mailstate .off{color:var(--bad)}button.alt{background:#222;color:#fff}
.ok .cdek{color:var(--ok)}.bad .cdek{color:var(--bad)}.warn .cdek{color:var(--warn)}
form{display:inline}.sync{display:block;margin:0 0 16px}button{margin:8px 0 0;display:block;padding:10px 16px;border:0;border-radius:8px;background:#e3161b;color:#fff;font:inherit;font-weight:700}
nav{margin:18px 0 0;color:var(--dim);font-size:13px}nav a{color:inherit}
</style></head><body><main>${body}</main></body></html>`,
    { status: 200, headers: HEADERS },
  );
}

async function render(token: string, days: number, message?: { ok: boolean; text: string }): Promise<Response> {
  if (!features.payments || !features.cdek) return page("<h1>Накладные СДЭК</h1><p>ЮKassa или СДЭК не подключены на сервере.</p>");
  let payments: Item[];
  let note: string | undefined;
  try {
    ({ items: payments, note } = await loadItems(days));
  } catch (err) {
    return page(`<h1>Накладные СДЭК</h1><p class="msg bad">Не удалось получить платежи из ЮKassa: ${esc((err as Error).message)}</p>`);
  }
  const states = await statesFor(payments);
  const missing = payments.filter((p, i) => p.metadata?.pvz && (states[i].kind === "none" || states[i].kind === "rejected")).length;
  const waiting: string[] = [];
  const shipped: string[] = [];
  payments.forEach((p, i) => {
    if (notShipped(p, states[i])) waiting.push(card(p, states[i], token, true));
    else shipped.push(card(p, states[i], token));
  });
  const other = days === 30 ? 60 : 30;
  return page(`<h1>Накладные СДЭК</h1>
<p class="lead">Оплаченные заказы за ${days} дн.: ${payments.length}. Ждут отправки: <b>${waiting.length}</b>${missing ? ` (без накладной: <b>${missing}</b>)` : ""}.</p>
${message ? `<p class="msg ${message.ok ? "ok" : "bad"}">${esc(message.text)}</p>` : ""}
${note ? `<p class="msg bad">${esc(note)}</p>` : ""}
${mailState()}
${payments.length ? syncButton(token) + (smtpConfig() ? mailButton(token) : "") : ""}
${
  payments.length
    ? `<h2>Не отправлены <small>— посылку ещё не сдали в СДЭК</small> · ${waiting.length}</h2>
${waiting.join("\n") || "<p class=\"dim\">Все оплаченные заказы уже переданы в СДЭК.</p>"}
<h2>Переданы в СДЭК · ${shipped.length}</h2>
${shipped.join("\n") || "<p class=\"dim\">Пока нет.</p>"}`
    : "<p>Оплаченных заказов пока нет.</p>"
}
<nav>Показаны последние ${days} дн. · <a href="?token=${esc(encodeURIComponent(token))}&days=${other}">показать за ${other} дн.</a></nav>`);
}

const daysFrom = (v: string | null) => Math.min(60, Math.max(1, Number.parseInt(v ?? "", 10) || 30));

export async function GET(request: Request) {
  const q = new URL(request.url).searchParams;
  const token = q.get("token");
  if (!authorized(token)) return notFound();
  return render(token!, daysFrom(q.get("days")));
}

export async function POST(request: Request) {
  const form = await request.formData().catch(() => null);
  const token = String(form?.get("token") ?? "");
  if (!authorized(token)) return notFound();
  const days = 30;
  if (form?.get("action") === "sync") return render(token, days, await syncTracks(60));
  if (form?.get("action") === "mail") {
    const r = await runMailJobs().catch((err) => ({ skipped: (err as Error).message, paid: 0, track: 0, storage: 0, errors: [] as string[] }));
    const text = r.skipped
      ? `Письма не отправлены: ${r.skipped}`
      : `Проверено. Отправлено писем: «спасибо за заказ» — ${r.paid}, с трек-номером — ${r.track}, о сроке хранения — ${r.storage}.` +
        (r.errors.length ? ` Ошибки: ${r.errors.join("; ")}` : "");
    return render(token, days, { ok: !r.skipped && !r.errors.length, text });
  }
  const orderId = String(form?.get("order") ?? "");
  const payment = (await listPaidSiteOrders(60).catch(() => [] as YooKassaPayment[])).find(
    (p) => p.metadata?.orderId === orderId,
  );
  let result: ShipResult;
  if (!payment) result = { ok: false, error: `Оплаченный заказ ${orderId} не найден в ЮKassa` };
  else result = await shipPaidOrder(payment, { retryRejected: true });
  const text = result.ok
    ? `${orderId}: ${result.existed ? "накладная уже была" : "накладная создана"}${result.trackingNumber ? ` — № ${result.trackingNumber}` : ""}. В таблице обновлена колонка «Доставка».`
    : `${orderId}: СДЭК не создал накладную — ${result.error}`;
  return render(token, days, { ok: result.ok, text });
}
