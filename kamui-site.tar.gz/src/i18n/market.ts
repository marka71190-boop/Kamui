import { PRODUCT } from "@/config/site";
import type { Currency } from "@/lib/format";
import type { Lang } from "./lang";

/** Версия сайта: язык, валюта цен и префикс адресов («» — русская, «/en» — английская). */
export interface Market {
  lang: Lang;
  currency: Currency;
  /** Цена 1 шт. в валюте версии */
  unitPrice: number;
  /** Префикс ссылок на разделы главной: «/» или «/en» */
  home: string;
}

export const RU_MARKET: Market = { lang: "ru", currency: "RUB", unitPrice: PRODUCT.price, home: "/" };

export const enMarket = (unitUsd: number): Market => ({ lang: "en", currency: "USD", unitPrice: unitUsd, home: "/en" });
