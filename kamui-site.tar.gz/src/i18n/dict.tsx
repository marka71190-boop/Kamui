/**
 * Тексты сайта на двух языках. Русская версия — основная, английская открывается по адресу /en.
 * Чтобы поправить формулировку, достаточно изменить строку здесь.
 */
import type { ReactNode } from "react";
import { formatNumber } from "@/lib/format";
import type { Lang } from "./lang";

const n = (v: number, lang: Lang) => formatNumber(v, lang);

const ru = {
  header: {
    skip: "Перейти к содержимому",
    home: "Kamui × Iosif Abramov — на главную",
    mainNav: "Основное меню",
    mobileNav: "Мобильное меню",
    nav: [
      { hash: "collection", label: "Коллекция" },
      { hash: "features", label: "Преимущества" },
      { hash: "story", label: "История" },
      { hash: "gallery", label: "Галерея" },
    ],
    left: "Осталось",
    buy: "Купить",
    openMenu: "Открыть меню",
    closeMenu: "Закрыть меню",
    mobileStock: (left: number, total: number) =>
      `Лимитированная серия · осталось ${n(left, "ru")} из ${n(total, "ru")}`,
    switchLabel: "English version",
    switchShort: "EN",
  },
  hero: {
    sliderAria: "Фотографии коллекции Kamui × Iosif Abramov",
    eyebrow: "Лимитированная серия",
    pieces: (total: number) => `${n(total, "ru")} экземпляров`,
    cta: "Оставить заявку",
    price: "Цена",
  },
  collection: {
    label: "Коллекция",
    title: (
      <>
        Не расходник.
        <br />
        <span className="red">Экземпляр</span> коллекции.
      </>
    ),
    lead1: (
      <>
        <strong>Kamui × Iosif Abramov</strong> — это лимитированная серия мела, созданная для игроков, которые
        чувствуют разницу между обычным ударом и идеальным контролем.
      </>
    ),
    lead2:
      "Каждый экземпляр объединяет японские технологии Kamui и опыт одного из сильнейших игроков современного бильярда.",
    total: (total: number) => (
      <>
        Всего создано <b>{n(total, "ru")}</b> экземпляров.
      </>
    ),
    editionTerm: "Тираж",
    editionUnit: "экземпляров во всей серии",
    availableTerm: "Доступно сейчас",
    availableUnit: (sold: number) => `осталось · продано ${n(sold, "ru")}`,
    madeTerm: "Производство",
    madeUnit: "технологии Kamui",
    modelTerm: "Модель",
  },
  features: {
    label: "Преимущества",
    title: (
      <>
        Точность <span className="red">в деталях</span>
      </>
    ),
    cards: [
      {
        title: "Контроль",
        body: <p>Стабильное сцепление кия с наклейкой и уверенность в каждом ударе.</p>,
      },
      {
        title: "Чистота игры",
        body: (
          <>
            <p>Мы решили одну из главных проблем обычного мела:</p>
            <ul>
              <li>меньше следов на столе;</li>
              <li>меньше загрязнения кия;</li>
              <li>более аккуратное использование.</li>
            </ul>
          </>
        ),
      },
      {
        title: "Коллекция",
        body: <p>Каждый мел является частью ограниченного выпуска Kamui × Iosif Abramov.</p>,
      },
    ] as { title: string; body: ReactNode }[],
  },
  story: {
    label: "История создания",
    title: (
      <>
        Почему появился
        <br />
        этот мел
      </>
    ),
    problem: "Проблема",
    problemText: "Игроки хотели больше контроля, но обычный мел оставлял много следов.",
    solution: "Решение",
    solutionText: "Создать формулу, которая сочетает сцепление, стабильность и чистоту.",
    formula: [
      { term: "Сцепление", note: "уверенный контакт наклейки с шаром" },
      { term: "Стабильность", note: "предсказуемый удар от партии к партии" },
      { term: "Чистота", note: "меньше следов на сукне, руках и кие" },
    ],
  },
  gallery: {
    label: "Галерея",
    hint: "Нажмите на фото, чтобы открыть его во весь экран",
    open: (caption: string) => `Открыть фото: ${caption}`,
    dialog: "Просмотр фотографий",
    lightbox: "Фотографии коллекции",
    close: "Закрыть",
  },
  slider: {
    prev: "Предыдущее фото",
    next: "Следующее фото",
    slide: (i: number, count: number, caption: string) => `${i} из ${count}: ${caption}`,
    dot: (i: number, caption: string) => `Фото ${i}: ${caption}`,
  },
  stock: {
    soldOut: "Тираж распродан",
    left: "Осталось",
    ofTotal: (total: number) => `шт. из ${n(total, "ru")}`,
    meter: "Продано экземпляров",
    meterText: (sold: number, total: number) => `Продано ${sold} из ${total}`,
    note: (sold: number, total: number) => `Продано ${n(sold, "ru")} из ${n(total, "ru")} экземпляров`,
  },
  qty: {
    less: "Уменьшить количество",
    more: "Увеличить количество",
    pcs: (q: number) => `${q} шт.`,
  },
  purchase: {
    label: "Покупка",
    title: (
      <>
        Закрепите за собой
        <br />
        <span className="red">свой экземпляр</span>
      </>
    ),
  },
  order: {
    formAria: "Заявка на покупку",
    perPiece: "за 1 шт.",
    quantity: "Количество",
    goods: "Товар",
    total: "Итого",
    soldOut: "Тираж распродан",
    placeOrder: "Оформить заказ",
    request: "Оставить заявку",
    notePay: (methods: string[]) =>
      `Оплата онлайн при оформлении через ЮKassa${
        methods.length ? `: ${methods.join(", ").replace("Банковская карта", "банковская карта")}` : ""
      }. Доставка СДЭК до пункта выдачи по всей России.`,
    noteRequest: "Без предоплаты: после заявки мы свяжемся с вами, чтобы уточнить доставку и оплату.",
    abroad: "Я нахожусь вне России",
    name: "ФИО",
    nameLatin: "ФИО латиницей",
    namePlaceholder: "Иванов Иван Иванович",
    nameLatinPlaceholder: "Ivanov Ivan",
    nameHint: "Как в паспорте — по нему СДЭК выдаёт посылку",
    nameLatinHint: "Как в загранпаспорте. Кириллица сразу переводится в латиницу",
    phone: "Телефон",
    email: "Email",
    country: "Страна",
    countryPlaceholder: "Например, Казахстан",
    city: "Город",
    cityPlaceholderRu: "Например, Краснодар",
    cityPlaceholderIntl: "Город",
    postalCode: "Индекс",
    postalPlaceholder: "Почтовый индекс",
    address: "Адрес",
    addressPlaceholder: "Улица, дом, квартира",
    comment: "Комментарий",
    commentPlaceholderRu: "Удобное время для звонка, пожелания по доставке",
    commentPlaceholderIntl: "Предпочтительная служба доставки, удобный мессенджер",
    consentBefore: "Я согласен на",
    consentLink: "обработку персональных данных",
    privacyLink: "Политика конфиденциальности",
    sending: "Отправляем…",
    toPayment: "Переходим к оплате…",
    pay: (sum: string) => `Перейти к оплате · ${sum}`,
    send: (q: number) => `Отправить заявку · ${q} шт.`,
    noteIntl: "Для заказов вне России стоимость и способ международной доставки рассчитываются индивидуально.",
    successTitle: "Заявка отправлена",
    successText: "Спасибо! Ваша заявка принята. Мы свяжемся с вами для уточнения доставки и оплаты.",
    noPaymentText:
      "Спасибо! Заявка принята, но онлайн-оплата сейчас недоступна. Мы свяжемся с вами, чтобы подтвердить заказ и выставить оплату.",
    orderNumber: "Номер заявки",
    again: "Оформить ещё одну заявку",
    failed: "Не удалось отправить заявку. Попробуйте ещё раз.",
    offline: "Нет соединения. Проверьте интернет и попробуйте ещё раз.",
    otherVersion: null as null | { text: string; link: string; href: string },
  },
  footer: {
    tagline: "Limited Edition 0.98 β · 2000 экземпляров · Made in Japan",
    requisites: "Реквизиты продавца",
    seller: "Продавец",
    inn: "ИНН",
    ogrnip: "ОГРНИП",
    legalAddress: "Юридический адрес",
    actualAddress: "Фактический адрес",
    phone: "Телефон",
    email: "Email",
    docs: "Документы",
    links: [
      { href: "/delivery", label: "Доставка и оплата" },
      { href: "/returns", label: "Обмен и возврат" },
      { href: "/oferta", label: "Публичная оферта" },
      { href: "/privacy", label: "Политика конфиденциальности" },
      { href: "/consent", label: "Согласие на обработку данных" },
    ],
    order: "Оставить заявку",
  },
  signature: "Подпись Иосифа Абрамова",
};

export type Dict = typeof ru;

const en: Dict = {
  header: {
    skip: "Skip to content",
    home: "Kamui × Iosif Abramov — home",
    mainNav: "Main menu",
    mobileNav: "Mobile menu",
    nav: [
      { hash: "collection", label: "Collection" },
      { hash: "features", label: "Features" },
      { hash: "story", label: "Story" },
      { hash: "gallery", label: "Gallery" },
    ],
    left: "Left",
    buy: "Buy",
    openMenu: "Open menu",
    closeMenu: "Close menu",
    mobileStock: (left, total) => `Limited edition · ${n(left, "en")} of ${n(total, "en")} left`,
    switchLabel: "Русская версия",
    switchShort: "RU",
  },
  hero: {
    sliderAria: "Kamui × Iosif Abramov collection photos",
    eyebrow: "Limited edition",
    pieces: (total) => `${n(total, "en")} pieces`,
    cta: "Order now",
    price: "Price",
  },
  collection: {
    label: "Collection",
    title: (
      <>
        Not a consumable.
        <br />A <span className="red">collector’s</span> piece.
      </>
    ),
    lead1: (
      <>
        <strong>Kamui × Iosif Abramov</strong> is a limited-edition chalk made for players who feel the difference
        between an ordinary shot and perfect control.
      </>
    ),
    lead2:
      "Every piece combines Kamui’s Japanese technology with the experience of one of the strongest players in modern billiards.",
    total: (total) => (
      <>
        Only <b>{n(total, "en")}</b> pieces have been made.
      </>
    ),
    editionTerm: "Edition",
    editionUnit: "pieces in the entire series",
    availableTerm: "Available now",
    availableUnit: (sold) => `left · ${n(sold, "en")} sold`,
    madeTerm: "Made in",
    madeUnit: "Kamui technology",
    modelTerm: "Model",
  },
  features: {
    label: "Features",
    title: (
      <>
        Precision <span className="red">in every detail</span>
      </>
    ),
    cards: [
      {
        title: "Control",
        body: <p>Consistent grip between cue tip and ball — and confidence in every shot.</p>,
      },
      {
        title: "Clean play",
        body: (
          <>
            <p>We solved one of the main problems of ordinary chalk:</p>
            <ul>
              <li>fewer marks on the table;</li>
              <li>less residue on the cue;</li>
              <li>neater, more precise application.</li>
            </ul>
          </>
        ),
      },
      {
        title: "Collectible",
        body: <p>Every piece is part of the limited Kamui × Iosif Abramov release.</p>,
      },
    ],
  },
  story: {
    label: "The story",
    title: (
      <>
        Why this chalk
        <br />
        was created
      </>
    ),
    problem: "Problem",
    problemText: "Players wanted more control, but ordinary chalk left too many marks.",
    solution: "Solution",
    solutionText: "A formula that combines grip, consistency and cleanliness.",
    formula: [
      { term: "Grip", note: "confident contact between tip and ball" },
      { term: "Consistency", note: "predictable shots, game after game" },
      { term: "Cleanliness", note: "fewer marks on cloth, hands and cue" },
    ],
  },
  gallery: {
    label: "Gallery",
    hint: "Tap a photo to view it full screen",
    open: (caption) => `Open photo: ${caption}`,
    dialog: "Photo viewer",
    lightbox: "Collection photos",
    close: "Close",
  },
  slider: {
    prev: "Previous photo",
    next: "Next photo",
    slide: (i, count, caption) => `${i} of ${count}: ${caption}`,
    dot: (i, caption) => `Photo ${i}: ${caption}`,
  },
  stock: {
    soldOut: "Sold out",
    left: "Left",
    ofTotal: (total) => `of ${n(total, "en")} pcs`,
    meter: "Pieces sold",
    meterText: (sold, total) => `${sold} of ${total} sold`,
    note: (sold, total) => `${n(sold, "en")} of ${n(total, "en")} pieces sold`,
  },
  qty: {
    less: "Decrease quantity",
    more: "Increase quantity",
    pcs: (q) => `${q} ${q === 1 ? "pc" : "pcs"}`,
  },
  purchase: {
    label: "Purchase",
    title: (
      <>
        Secure
        <br />
        <span className="red">your piece</span>
      </>
    ),
  },
  order: {
    formAria: "Order request",
    perPiece: "per piece",
    quantity: "Quantity",
    goods: "Items",
    total: "Total",
    soldOut: "Sold out",
    placeOrder: "Place an order",
    request: "Place an order",
    notePay: () => "",
    noteRequest:
      "No prepayment: after you place an order, we will contact you to arrange international shipping and payment.",
    abroad: "",
    name: "Full name",
    nameLatin: "Full name (Latin letters)",
    namePlaceholder: "John Smith",
    nameLatinPlaceholder: "John Smith",
    nameHint: "As in your passport",
    nameLatinHint: "As in your passport. Cyrillic is converted to Latin automatically",
    phone: "Phone",
    email: "Email",
    country: "Country",
    countryPlaceholder: "e.g. Germany",
    city: "City",
    cityPlaceholderRu: "City",
    cityPlaceholderIntl: "City",
    postalCode: "Postal code",
    postalPlaceholder: "ZIP / postal code",
    address: "Address",
    addressPlaceholder: "Street, building, apartment",
    comment: "Comment",
    commentPlaceholderRu: "Anything we should know",
    commentPlaceholderIntl: "Preferred carrier, messenger for contact",
    consentBefore: "I agree to the",
    consentLink: "processing of my personal data",
    privacyLink: "Privacy policy (in Russian)",
    sending: "Sending…",
    toPayment: "Redirecting to payment…",
    pay: (sum) => `Proceed to payment · ${sum}`,
    send: (q) => `Send order request · ${q} ${q === 1 ? "pc" : "pcs"}`,
    noteIntl:
      "International shipping cost and method are calculated individually. Prices are shown in US dollars at the current exchange rate.",
    successTitle: "Request sent",
    successText: "Thank you! Your order request has been received. We will contact you to arrange shipping and payment.",
    noPaymentText: "Thank you! Your order request has been received. We will contact you to arrange shipping and payment.",
    orderNumber: "Order number",
    again: "Place another order",
    failed: "Could not send the request. Please try again.",
    offline: "No connection. Check your internet and try again.",
    otherVersion: { text: "Ordering within Russia?", link: "Switch to the Russian version", href: "/#buy" },
  },
  footer: {
    tagline: "Limited Edition 0.98 β · 2000 pieces · Made in Japan",
    requisites: "Seller details",
    seller: "Seller",
    inn: "Taxpayer ID (INN)",
    ogrnip: "Registration No. (OGRNIP)",
    legalAddress: "Registered address",
    actualAddress: "Business address",
    phone: "Phone",
    email: "Email",
    docs: "Documents",
    links: [
      { href: "/delivery", label: "Delivery & payment (RU)" },
      { href: "/returns", label: "Returns (RU)" },
      { href: "/oferta", label: "Public offer (RU)" },
      { href: "/privacy", label: "Privacy policy (RU)" },
      { href: "/consent", label: "Data processing consent (RU)" },
    ],
    order: "Place an order",
  },
  signature: "Signature of Iosif Abramov",
};

export const DICT: Record<Lang, Dict> = { ru, en };

export const t = (lang: Lang = "ru"): Dict => DICT[lang];
