/**
 * POST /api/payments/yookassa/webhook — уведомления ЮKassa о статусе платежа.
 * Укажите этот адрес в личном кабинете ЮKassa: Интеграция → HTTP-уведомления,
 * события payment.succeeded и payment.canceled.
 *
 * Уведомление не подписано, поэтому статус всегда перепроверяется запросом к API ЮKassa.
 * После оплаты (если подключён СДЭК) создаётся отправление — уже после ответа ЮKassa.
 */
import { revalidatePath } from "next/cache";
import { after } from "next/server";
import { features } from "@/config/features";
import { shipPaidOrder } from "@/lib/delivery/ship";
import { json } from "@/lib/http";
import { updateOrder } from "@/lib/orders/store";
import type { OrderStatus } from "@/lib/orders/types";
import { getPayment, type YooKassaNotification } from "@/lib/payments/yookassa";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const STATUS_MAP: Partial<Record<string, OrderStatus>> = {
  succeeded: "paid",
  canceled: "payment_canceled",
  pending: "awaiting_payment",
  waiting_for_capture: "awaiting_payment",
};

export async function POST(request: Request) {
  if (!features.payments) return json({ ok: false, error: "Оплата не подключена" }, 404);

  let body: YooKassaNotification;
  try {
    body = (await request.json()) as YooKassaNotification;
  } catch {
    return json({ ok: false }, 400);
  }
  if (body?.type !== "notification" || !body.object?.id) return json({ ok: false }, 400);
  // Возвраты и прочие события пока не обрабатываем
  if (body.event && !body.event.startsWith("payment.")) return json({ ok: true, skipped: body.event });

  try {
    const payment = await getPayment(body.object.id);
    const orderId = payment.metadata?.orderId;
    if (!orderId) return json({ ok: true, skipped: "no orderId" });

    await updateOrder(orderId, {
      status: STATUS_MAP[payment.status],
      payment: {
        provider: "yookassa",
        paymentId: payment.id,
        status: payment.status,
        paidAt: payment.status === "succeeded" ? (payment.captured_at ?? new Date().toISOString()) : undefined,
        test: payment.test || undefined,
      },
      // Тестовая оплата: настоящую накладную в СДЭК не создаём
      ...(payment.test && payment.status === "succeeded" && payment.metadata?.pvz
        ? {
            delivery: {
              provider: "cdek" as const,
              label: `${payment.metadata.delivery || `СДЭК ПВЗ ${payment.metadata.pvz}`} · тестовая оплата, накладная не создавалась`,
            },
          }
        : {}),
    });

    // Оплата прошла — сразу обновляем счётчик остатка на страницах
    if (payment.status === "succeeded" && !payment.test) {
      try {
        revalidatePath("/");
        revalidatePath("/en");
      } catch (err) {
        console.warn("[yookassa] Не удалось обновить страницы:", (err as Error).message);
      }
    }

    if (
      payment.status === "succeeded" &&
      !payment.test &&
      features.cdek &&
      features.cdekAutoShipment &&
      payment.metadata?.pvz
    ) {
      after(() => shipPaidOrder(payment));
    }
    return json({ ok: true });
  } catch (err) {
    console.error("[yookassa] Ошибка обработки уведомления:", err);
    // 500 → ЮKassa повторит уведомление позже
    return json({ ok: false }, 500);
  }
}
