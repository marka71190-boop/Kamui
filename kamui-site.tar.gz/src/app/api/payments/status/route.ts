/**
 * GET /api/payments/status?order=KA-260925-AB12[&payment=<id>] — статус оплаты заказа.
 * Нужен странице, на которую покупатель возвращается после ЮKassa. Отдаёт только статус, без личных данных.
 */
import { features } from "@/config/features";
import { clientIp, createRateLimiter, json } from "@/lib/http";
import { ORDER_ID_RE } from "@/lib/orders/id";
import { findPaymentForOrder, getPayment, type YooKassaPayment } from "@/lib/payments/yookassa";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const rateLimit = createRateLimiter({ limit: 40, windowMs: 10 * 60 * 1000 });

export async function GET(request: Request) {
  if (!features.payments) return json({ ok: false, error: "Оплата не подключена" }, 404);
  if (!rateLimit(clientIp(request)).ok) return json({ ok: false, error: "Слишком много запросов" }, 429);

  const params = new URL(request.url).searchParams;
  const orderId = params.get("order") ?? "";
  const paymentId = params.get("payment") ?? "";
  if (!ORDER_ID_RE.test(orderId)) return json({ ok: false, error: "Некорректный номер заказа" }, 400);

  try {
    let payment: YooKassaPayment | null = null;
    if (/^[\w-]{10,60}$/.test(paymentId)) {
      const p = await getPayment(paymentId).catch(() => null);
      if (p?.metadata?.orderId === orderId) payment = p;
    }
    payment ??= await findPaymentForOrder(orderId);
    if (!payment) return json({ ok: true, status: "unknown" });
    return json({
      ok: true,
      status: payment.status,
      amount: Number(payment.amount.value),
      ...(payment.status === "pending" && payment.confirmation?.confirmation_url
        ? { paymentUrl: payment.confirmation.confirmation_url }
        : {}),
    });
  } catch (err) {
    console.error("[payments] status:", err);
    return json({ ok: false, error: "Не удалось проверить оплату" }, 502);
  }
}
