/**
 * POST /api/delivery/cdek/calculate { cityCode, quantity } — стоимость и срок доставки до ПВЗ.
 * GET  /api/delivery/cdek/calculate?cityCode=44&quantity=1 — то же самое, для проверки в браузере.
 */
import { features } from "@/config/features";
import { PRODUCT } from "@/config/site";
import { calculateDelivery } from "@/lib/delivery/cdek";
import { customerDeliveryPrice } from "@/lib/delivery/price";
import { clientIp, createRateLimiter, json } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const rateLimit = createRateLimiter({ limit: 60, windowMs: 10 * 60 * 1000 });

export async function GET(request: Request) {
  const q = new URL(request.url).searchParams;
  return quote(request, { cityCode: q.get("cityCode"), quantity: q.get("quantity") });
}

export async function POST(request: Request) {
  let body: { cityCode?: unknown; quantity?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return json({ ok: false, error: "Некорректный запрос" }, 400);
  }
  return quote(request, body);
}

async function quote(request: Request, body: { cityCode?: unknown; quantity?: unknown }) {
  if (!features.cdek) return json({ ok: false, error: "Доставка СДЭК пока не подключена" }, 503);
  if (!rateLimit(clientIp(request)).ok) return json({ ok: false, error: "Слишком много запросов" }, 429);
  const cityCode = Number(body.cityCode);
  const quantity = Math.min(PRODUCT.maxPerOrder, Math.max(1, Math.trunc(Number(body.quantity) || 1)));
  if (!Number.isInteger(cityCode) || cityCode <= 0) return json({ ok: false, error: "Не указан cityCode" }, 400);
  try {
    const quote = await calculateDelivery({ toCityCode: cityCode, quantity });
    // Покупателю показываем цену с наценкой; тариф СДЭК наружу не отдаём.
    const { periodMin, periodMax } = quote;
    return json({ ok: true, quote: { cost: customerDeliveryPrice(quote.cost), periodMin, periodMax } });
  } catch (err) {
    console.error("[cdek] calculate:", err);
    return json({ ok: false, error: "Не удалось рассчитать доставку", detail: String((err as Error).message).slice(0, 300) }, 502);
  }
}
