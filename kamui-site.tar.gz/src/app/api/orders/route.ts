/**
 * POST /api/orders — приём заявки.
 * Проверяет форму и остаток, при подключённом СДЭК заново рассчитывает доставку до выбранного ПВЗ,
 * создаёт номер заказа, сохраняет заявку (локальный файл + Google Таблица)
 * и, если включена ЮKassa, создаёт платёж и возвращает ссылку на оплату.
 *
 * Скорость: остаток берётся из кэша (не ждём таблицу), остаток и СДЭК считаются параллельно,
 * запись в таблицу и создание платежа идут одновременно, а номер платежа дописывается в таблицу
 * уже после ответа покупателю.
 */
import { after } from "next/server";
import { features } from "@/config/features";
import { PRODUCT } from "@/config/site";
import { calculateDelivery, findPickupPoint } from "@/lib/delivery/cdek";
import { customerDeliveryPrice } from "@/lib/delivery/price";
import { clientIp, createRateLimiter, json } from "@/lib/http";
import { buildOrder, deliveryLabel } from "@/lib/orders/create";
import { OrderStorageError, saveOrder, updateOrder } from "@/lib/orders/store";
import type { OrderDelivery } from "@/lib/orders/types";
import { normalizeOrderInput, validateOrderInput, type OrderInput } from "@/lib/orders/validation";
import { createPayment, siteOriginFor } from "@/lib/payments/yookassa";
import { getUsdPrice } from "@/lib/currency";
import { getStock } from "@/lib/stock";

export const runtime = "nodejs";
// Без force-dynamic: так остаток из таблицы берётся из кэша данных (обновляется раз в минуту), а не ждёт ответа таблицы.
// Google Apps Script иногда отвечает несколько секунд — даём функции запас по времени.
export const maxDuration = 60;

const rateLimit = createRateLimiter({ limit: 5, windowMs: 10 * 60 * 1000 });
/** Результат промиса или null, если он не успел за ms миллисекунд (или упал). */
function within<T>(p: Promise<T>, ms: number): Promise<T | null> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<null>((r) => (timer = setTimeout(() => r(null), ms)));
  return Promise.race([p.catch(() => null), timeout]).finally(() => clearTimeout(timer));
}

type DeliveryResult =
  | { ok: true; delivery: OrderDelivery; cost: number }
  | { ok: false; error: string; field?: "city" | "pickupPoint" }
  | { ok: "unavailable"; delivery: OrderDelivery };

/** Доставка СДЭК до ПВЗ: проверяем пункт и считаем цену на сервере (цене из браузера не доверяем). */
async function resolveCdekDelivery(input: OrderInput): Promise<DeliveryResult> {
  try {
    const [point, quote] = await Promise.all([
      findPickupPoint(input.cityCode, input.pickupPoint),
      calculateDelivery({ toCityCode: input.cityCode, quantity: input.quantity }),
    ]);
    if (!point) return { ok: false, error: "Этот пункт выдачи сейчас недоступен — выберите другой", field: "pickupPoint" };
    const price = customerDeliveryPrice(quote.cost);
    const delivery: OrderDelivery = {
      provider: "cdek",
      label: "",
      cdek: {
        cityCode: input.cityCode,
        cityName: input.city,
        pickupPointCode: point.code,
        pickupPointAddress: point.address,
        tariffCode: quote.tariffCode,
        cost: quote.cost,
        price,
        periodMin: quote.periodMin,
        periodMax: quote.periodMax,
      },
    };
    delivery.label = deliveryLabel(delivery);
    return { ok: true, delivery, cost: price };
  } catch (err) {
    // СДЭК не отвечает — заявку всё равно принимаем, менеджер уточнит доставку.
    console.error("[orders] СДЭК недоступен:", err);
    return {
      ok: "unavailable",
      delivery: {
        provider: "cdek",
        label: `СДЭК ПВЗ ${input.pickupPoint} · ${input.city} · стоимость не рассчитана`,
        cdek: { cityCode: input.cityCode, cityName: input.city, pickupPointCode: input.pickupPoint },
      },
    };
  }
}

export async function POST(request: Request) {
  const ip = clientIp(request);
  const limited = rateLimit(ip);
  if (!limited.ok) {
    return json({ ok: false, error: "Слишком много заявок подряд. Попробуйте через несколько минут. / Too many requests, please try again in a few minutes." }, 429, {
      "Retry-After": String(limited.retryAfter),
    });
  }

  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    return json({ ok: false, error: "Некорректный запрос" }, 400);
  }

  const input = normalizeOrderInput(raw);

  // Бот заполнил скрытое поле — делаем вид, что всё хорошо, но ничего не сохраняем.
  if (input.company) return json({ ok: true, orderId: "KA-000000-0000" }, 201);

  const useCdek = features.cdek && input.region === "ru";
  const formError = input.lang === "en" ? "Please check the form" : "Проверьте поля формы";

  // 1. Поля формы — сразу, без внешних запросов
  const fieldErrors = validateOrderInput(input, { maxQuantity: PRODUCT.maxPerOrder, requirePickupPoint: useCdek });
  if (Object.keys(fieldErrors).length > 0) return json({ ok: false, error: formError, fieldErrors }, 400);

  // 2. Остаток, доставка СДЭК и курс доллара — параллельно.
  //    Остаток — из кэша; если таблица долго не отвечает, не держим покупателя дольше 2 секунд.
  const [stock, cdek, usd] = await Promise.all([
    within(getStock(), 2_000),
    useCdek ? resolveCdekDelivery(input) : Promise.resolve(null),
    input.lang === "en" ? getUsdPrice() : Promise.resolve(null),
  ]);
  if (stock) {
    const errors = validateOrderInput(input, {
      maxQuantity: Math.min(PRODUCT.maxPerOrder, stock.remaining),
      requirePickupPoint: useCdek,
    });
    if (Object.keys(errors).length > 0) {
      const status = errors.quantity && stock.remaining < input.quantity ? 409 : 400;
      return json({ ok: false, error: formError, fieldErrors: errors }, status);
    }
  }

  let delivery: OrderDelivery | undefined;
  let deliveryCost = 0;
  let deliveryKnown = true;
  if (usd) {
    // Заказ с английской версии: цена показывалась в долларах — фиксируем её в таблице
    delivery = {
      provider: "international",
      label: `Международная доставка — уточняется · англ. версия сайта: $${usd.unit}/шт., итого $${usd.unit * input.quantity}${
        usd.rate ? ` (курс ${usd.rate.toFixed(2)} ₽/$)` : ""
      }`,
    };
  }
  if (cdek) {
    const r = cdek;
    if (r.ok === false) {
      return json({ ok: false, error: r.error, fieldErrors: r.field ? { [r.field]: r.error } : undefined }, 400);
    }
    delivery = r.delivery;
    if (r.ok === true) deliveryCost = r.cost;
    else deliveryKnown = false;
  }

  // Онлайн-оплата — только для России и только когда сумма доставки известна.
  // Тестовый магазин ЮKassa — оплата только для того, кто открыл сайт по секретной ссылке.
  const testToken = process.env.PAYMENTS_TEST_TOKEN ?? "";
  const paymentsHere =
    features.payments &&
    input.region === "ru" &&
    (!features.paymentsTestShop || (testToken.length >= 8 && input.payTest === testToken));
  const payOnline = paymentsHere && deliveryKnown;

  try {
    const order = buildOrder(input, {
      meta: { ip, userAgent: request.headers.get("user-agent")?.slice(0, 200) ?? undefined },
      delivery,
      deliveryCost,
      awaitingPayment: payOnline,
    });

    if (payOnline) {
      // Запись в таблицу и платёж — одновременно. Не сохранилась заявка — платёж просто истечёт неоплаченным.
      const [saved, pay] = await Promise.allSettled([
        saveOrder(order),
        createPayment(order, { origin: siteOriginFor(request) }),
      ]);
      if (saved.status === "rejected") throw saved.reason;
      if (pay.status === "fulfilled") {
        const payment = pay.value;
        // Номер платежа дописываем в таблицу уже после ответа — покупатель сразу уходит на оплату
        after(() =>
          updateOrder(order.id, {
            payment: {
              provider: "yookassa",
              paymentId: payment.paymentId,
              status: payment.status,
              confirmationUrl: payment.confirmationUrl,
              test: payment.test || undefined,
            },
          }),
        );
        return json(
          { ok: true, orderId: order.id, total: order.total, paymentId: payment.paymentId, paymentUrl: payment.confirmationUrl },
          201,
        );
      }
      // Заявка уже сохранена — менеджер свяжется и выставит оплату вручную.
      console.error(`[orders] Не удалось создать платёж для ${order.id}:`, pay.reason);
      after(() => updateOrder(order.id, { status: "new" }));
      return json({ ok: true, orderId: order.id, total: order.total, paymentUnavailable: true }, 201);
    }

    await saveOrder(order);
    return json(
      {
        ok: true,
        orderId: order.id,
        total: order.total,
        ...(paymentsHere ? { paymentUnavailable: true } : {}),
      },
      201,
    );
  } catch (err) {
    if (!(err instanceof OrderStorageError)) console.error("[orders] Ошибка:", err);
    return json(
      {
        ok: false,
        error:
          input.lang === "en"
            ? "Could not send the request. Please try again in a minute."
            : "Не удалось отправить заявку. Попробуйте ещё раз через минуту.",
      },
      500,
    );
  }
}
