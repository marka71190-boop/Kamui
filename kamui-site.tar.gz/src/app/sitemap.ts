import type { MetadataRoute } from "next";
import { SITE } from "@/config/site";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: `${SITE.url}/`, changeFrequency: "daily", priority: 1 },
    { url: `${SITE.url}/en`, changeFrequency: "daily", priority: 0.8 },
    { url: `${SITE.url}/delivery`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${SITE.url}/returns`, changeFrequency: "yearly", priority: 0.3 },
    { url: `${SITE.url}/oferta`, changeFrequency: "yearly", priority: 0.3 },
    { url: `${SITE.url}/privacy`, changeFrequency: "yearly", priority: 0.2 },
    { url: `${SITE.url}/consent`, changeFrequency: "yearly", priority: 0.1 },
  ];
}
