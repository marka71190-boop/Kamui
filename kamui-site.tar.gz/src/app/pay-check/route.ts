/**
 * GET /pay-check?token=<PAYMENTS_TEST_TOKEN> — служебная проверка подключения ЮKassa.
 * Показывает, приняты ли ключи, боевой ли магазин, подключены ли чеки, адрес для уведомлений
 * и из чего складывается остаток на сайте.
 * Без правильного токена отвечает 404. Платежей не создаёт.
 */
import { features } from "@/config/features";
import { json } from "@/lib/http";
import { getShopInfo, paidQuantity, shouldSendReceipt, siteOriginFor } from "@/lib/payments/yookassa";
import { probeSheetStock } from "@/lib/orders/stores/google-sheets";
import { getStock, stockDiagnostics } from "@/lib/stock";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const noindex = { "X-Robots-Tag": "noindex, nofollow" };

export async function GET(request: Request) {
  const token = process.env.PAYMENTS_TEST_TOKEN ?? "";
  const given = new URL(request.url).searchParams.get("token") ?? "";
  if (token.length < 8 || given !== token) return json({ ok: false }, 404, noindex);

  const probe = new URL(request.url).searchParams.get("probe") === "1";
  const [stockNow, stockOnPage, paid, sheetProbe] = await Promise.all([
    getStock({ fresh: true }).catch((err: Error) => ({ error: err.message })),
    getStock().catch((err: Error) => ({ error: err.message })),
    features.payments ? paidQuantity({ fresh: true }).catch((err: Error) => ({ error: err.message })) : null,
    probe && features.googleSheets ? probeSheetStock().catch((err: Error) => ({ error: err.message })) : null,
  ]);
  const base = {
    stock: { now: stockNow, cached: stockOnPage, paidOnline: paid, ...stockDiagnostics(), ...(sheetProbe ? { sheetProbe } : {}) },
    paymentsEnabled: features.payments,
    onlyBySecretLink: features.paymentsTestShop,
    cdek: features.cdek,
    webhookUrl: `${siteOriginFor(request)}/api/payments/yookassa/webhook`,
  };
  if (!features.payments) return json({ ok: true, ...base, shop: null }, 200, noindex);
  try {
    const me = await getShopInfo({ fresh: true });
    return json(
      {
        ok: true,
        ...base,
        shop: {
          accountId: me.account_id,
          test: me.test,
          status: me.status,
          fiscalization: me.fiscalization ?? { enabled: me.fiscalization_enabled },
          paymentMethods: me.payment_methods,
        },
        receiptsSent: await shouldSendReceipt(),
      },
      200,
      noindex,
    );
  } catch (err) {
    return json({ ok: false, ...base, error: String((err as Error).message).slice(0, 300) }, 502, noindex);
  }
}
