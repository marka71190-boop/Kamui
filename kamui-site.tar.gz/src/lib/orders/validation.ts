/**
 * Валидация формы заявки. Общая для браузера и сервера — без внешних зависимостей.
 */
import type { Lang } from "@/i18n/lang";
import { toLatin } from "@/lib/translit";
import type { OrderRegion } from "./types";

export interface OrderInput {
  /** Язык сайта, с которого пришла заявка (для текстов ошибок) */
  lang: Lang;
  region: OrderRegion;
  /** ФИО полностью. Для заказов вне России — латиницей (кириллица переводится автоматически). */
  name: string;
  phone: string;
  email: string;
  quantity: number;
  city: string;
  comment: string;
  /** Для заказов вне России */
  country: string;
  postalCode: string;
  address: string;
  consent: boolean;
  /** СДЭК: код города и код пункта выдачи (когда включён выбор ПВЗ) */
  cityCode: number;
  pickupPoint: string;
  /** Токен тестовой оплаты (из секретной ссылки ?paytest=) */
  payTest: string;
  /** Ловушка для ботов — у людей всегда пустая */
  company: string;
}

export type OrderField = Exclude<keyof OrderInput, "lang" | "region" | "company" | "cityCode" | "payTest">;
export type FieldErrors = Partial<Record<OrderField, string>>;

export const LIMITS = {
  name: 80,
  phone: 32,
  email: 120,
  city: 80,
  country: 80,
  postalCode: 16,
  address: 200,
  comment: 1000,
} as const;

const clean = (v: unknown, max: number) =>
  typeof v === "string"
    ? v
        .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
        .replace(/[ \t]+/g, " ")
        .trim()
        .slice(0, max)
    : "";

/** Приводит произвольный JSON к OrderInput (обрезает, чистит, приводит типы). */
export function normalizeOrderInput(raw: unknown): OrderInput {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const q = typeof r.quantity === "number" ? r.quantity : Number.parseInt(String(r.quantity ?? ""), 10);
  const cityCode = Number(r.cityCode);
  const lang: Lang = r.lang === "en" ? "en" : "ru";
  // Английская версия сайта — всегда заказ из-за рубежа
  const region: OrderRegion = lang === "en" || r.region === "intl" ? "intl" : "ru";
  const name = clean(r.name, LIMITS.name);
  return {
    lang,
    region,
    name: region === "intl" ? toLatin(name) : name,
    phone: clean(r.phone, LIMITS.phone),
    email: clean(r.email, LIMITS.email).toLowerCase(),
    quantity: Number.isFinite(q) ? Math.trunc(q) : 0,
    city: clean(r.city, LIMITS.city),
    comment: clean(r.comment, LIMITS.comment),
    country: clean(r.country, LIMITS.country),
    postalCode: clean(r.postalCode, LIMITS.postalCode),
    address: clean(r.address, LIMITS.address),
    consent: r.consent === true,
    cityCode: Number.isInteger(cityCode) && cityCode > 0 ? cityCode : 0,
    pickupPoint: clean(r.pickupPoint, 32).replace(/[^\p{L}\d_-]/gu, ""),
    payTest: clean(r.payTest, 64),
    company: clean(r.company, 100),
  };
}

export const digitsOnly = (s: string) => s.replace(/\D/g, "");

/** Российский номер → «+7 (999) 123-45-67». Иначе возвращает null. */
export function normalizeRuPhone(phone: string): string | null {
  let d = digitsOnly(phone);
  if (d.length === 10 && d.startsWith("9")) d = "7" + d;
  if (d.length === 11 && d.startsWith("8")) d = "7" + d.slice(1);
  if (d.length !== 11 || !d.startsWith("7")) return null;
  return `+7 (${d.slice(1, 4)}) ${d.slice(4, 7)}-${d.slice(7, 9)}-${d.slice(9, 11)}`;
}

/** Международный номер → «+<цифры>». Иначе null. */
export function normalizeIntlPhone(phone: string): string | null {
  const d = digitsOnly(phone);
  if (d.length < 8 || d.length > 15) return null;
  return "+" + d;
}

export function normalizePhone(phone: string, region: OrderRegion): string | null {
  return region === "ru" ? normalizeRuPhone(phone) : normalizeIntlPhone(phone);
}

/** Маска ввода телефона для России: +7 (999) 123-45-67 */
export function formatRuPhoneInput(value: string): string {
  let d = digitsOnly(value);
  if (!d) return "";
  if (d.startsWith("8")) d = "7" + d.slice(1);
  if (!d.startsWith("7")) d = "7" + d;
  d = d.slice(0, 11);
  let out = "+7";
  if (d.length > 1) out += " (" + d.slice(1, 4);
  if (d.length >= 4) out += ")";
  if (d.length > 4) out += " " + d.slice(4, 7);
  if (d.length > 7) out += "-" + d.slice(7, 9);
  if (d.length > 9) out += "-" + d.slice(9, 11);
  return out;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const NAME_RE = /^[\p{L}][\p{L}\s'’.-]*$/u;
const LATIN_NAME_RE = /^[A-Za-z][A-Za-z\s'’.-]*$/;
const POSTAL_RE = /^[\p{L}\d][\p{L}\d\s-]{1,14}$/u;

/** Слова ФИО: «Иванов Иван Иванович» → 3, «Анна-Мария Смит» → 2 */
export const nameWords = (name: string) => name.split(/\s+/).filter((w) => /\p{L}/u.test(w)).length;

const MESSAGES = {
  ru: {
    nameEmpty: "Укажите ФИО",
    nameLetters: "ФИО может содержать только буквы",
    nameFull: "Укажите фамилию и имя полностью — как в паспорте",
    nameLatin: "ФИО латиницей: имя и фамилия, как в загранпаспорте",
    phoneEmpty: "Укажите телефон",
    phoneRu: "Номер в формате +7 (999) 123-45-67",
    phoneIntl: "Укажите номер с кодом страны",
    emailEmpty: "Укажите email",
    emailBad: "Проверьте email",
    qtyMin: "Минимум 1 шт.",
    qtyMax: (n: number) => `Доступно не более ${n} шт.`,
    soldOut: "Тираж распродан",
    city: "Укажите город",
    cityPick: "Выберите город из списка",
    pickupPoint: "Выберите пункт выдачи СДЭК",
    country: "Укажите страну",
    postalEmpty: "Укажите индекс",
    postalBad: "Проверьте индекс",
    address: "Укажите адрес: улица, дом, квартира",
    consent: "Нужно согласие на обработку персональных данных",
  },
  en: {
    nameEmpty: "Enter your full name",
    nameLetters: "Use letters only",
    nameFull: "Enter your first and last name",
    nameLatin: "Full name in Latin letters, as in your passport",
    phoneEmpty: "Enter your phone number",
    phoneRu: "Format: +7 (999) 123-45-67",
    phoneIntl: "Include the country code",
    emailEmpty: "Enter your email",
    emailBad: "Check your email",
    qtyMin: "Minimum 1 pc",
    qtyMax: (n: number) => `Up to ${n} pcs available`,
    soldOut: "Sold out",
    city: "Enter your city",
    cityPick: "Choose a city from the list",
    pickupPoint: "Choose a pickup point",
    country: "Enter your country",
    postalEmpty: "Enter your postal code",
    postalBad: "Check your postal code",
    address: "Enter your address: street, building, apartment",
    consent: "Consent to personal data processing is required",
  },
};

export function validateOrderInput(
  input: OrderInput,
  opts: { maxQuantity: number; requirePickupPoint?: boolean },
): FieldErrors {
  const e: FieldErrors = {};
  const m = MESSAGES[input.lang] ?? MESSAGES.ru;

  if (input.name.length < 2) e.name = m.nameEmpty;
  else if (input.region === "intl" ? !LATIN_NAME_RE.test(input.name) : !NAME_RE.test(input.name))
    e.name = input.region === "intl" ? m.nameLatin : m.nameLetters;
  else if (nameWords(input.name) < 2) e.name = input.region === "intl" ? m.nameLatin : m.nameFull;

  if (!input.phone) e.phone = m.phoneEmpty;
  else if (!normalizePhone(input.phone, input.region)) e.phone = input.region === "ru" ? m.phoneRu : m.phoneIntl;

  if (!input.email) e.email = m.emailEmpty;
  else if (!EMAIL_RE.test(input.email)) e.email = m.emailBad;

  if (!Number.isInteger(input.quantity) || input.quantity < 1) e.quantity = m.qtyMin;
  else if (input.quantity > opts.maxQuantity) e.quantity = opts.maxQuantity > 0 ? m.qtyMax(opts.maxQuantity) : m.soldOut;

  if (input.city.length < 2) e.city = m.city;

  if (input.region === "ru" && opts.requirePickupPoint) {
    if (!input.cityCode) e.city = m.cityPick;
    else if (!input.pickupPoint) e.pickupPoint = m.pickupPoint;
  }

  if (input.region === "intl") {
    if (input.country.length < 2) e.country = m.country;
    if (!input.postalCode) e.postalCode = m.postalEmpty;
    else if (!POSTAL_RE.test(input.postalCode)) e.postalCode = m.postalBad;
    if (input.address.length < 5) e.address = m.address;
  }

  if (!input.consent) e.consent = m.consent;

  return e;
}
