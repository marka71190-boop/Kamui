import { PRODUCT } from "@/config/site";
import { formatPrice } from "@/lib/format";
import { generateOrderId } from "./id";
import { saveOrder } from "./store";
import type { Order, OrderDelivery } from "./types";
import { normalizePhone, type OrderInput } from "./validation";

/** Текст для колонки «Доставка» в таблице. */
export function deliveryLabel(d: OrderDelivery): string {
  if (d.provider !== "cdek" || !d.cdek?.pickupPointCode) return d.label;
  const c = d.cdek;
  const parts = [`СДЭК ПВЗ ${c.pickupPointCode}`, [c.cityName, c.pickupPointAddress].filter(Boolean).join(", ")];
  if (c.price !== undefined && c.cost !== undefined) {
    if (c.price === 0) parts.push(`бесплатно для покупателя (тариф СДЭК ${formatPrice(c.cost)})`);
    else if (c.price !== c.cost) parts.push(`${formatPrice(c.price)} (тариф СДЭК ${formatPrice(c.cost)})`);
    else parts.push(formatPrice(c.price));
  } else if (c.cost !== undefined) parts.push(formatPrice(c.cost));
  if (c.periodMin && c.periodMax)
    parts.push(c.periodMin === c.periodMax ? `${c.periodMin} дн.` : `${c.periodMin}–${c.periodMax} дн.`);
  if (c.trackingNumber) parts.push(`трек ${c.trackingNumber}`);
  return parts.filter(Boolean).join(" · ");
}

export interface CreateOrderOptions {
  meta?: Order["meta"];
  /** Доставка, уже рассчитанная на сервере (СДЭК) */
  delivery?: OrderDelivery;
  /** Сколько платит покупатель за доставку, ₽ */
  deliveryCost?: number;
  /** Сразу ждём онлайн-оплату */
  awaitingPayment?: boolean;
}

/** Собирает заказ из проверенной формы и сохраняет его. */
/** Собирает заказ (номер, суммы, доставка) без сохранения. */
export function buildOrder(input: OrderInput, opts: CreateOrderOptions = {}): Order {
  const isRu = input.region === "ru";
  const itemsTotal = PRODUCT.price * input.quantity;
  const deliveryCost = Math.max(0, Math.ceil(opts.deliveryCost ?? 0));
  const order: Order = {
    id: generateOrderId(),
    createdAt: new Date().toISOString(),
    status: opts.awaitingPayment ? "awaiting_payment" : "new",
    region: input.region,
    customer: {
      name: input.name,
      phone: normalizePhone(input.phone, input.region) ?? input.phone,
      email: input.email,
    },
    address: isRu
      ? { country: "Россия", city: input.city }
      : { country: input.country, city: input.city, postalCode: input.postalCode, address: input.address },
    quantity: input.quantity,
    unitPrice: PRODUCT.price,
    itemsTotal,
    deliveryCost,
    total: itemsTotal + deliveryCost,
    currency: "RUB",
    comment: input.comment,
    delivery:
      opts.delivery ??
      (isRu
        ? { provider: "cdek", label: "СДЭК — уточняется" }
        : { provider: "international", label: "Международная доставка — уточняется" }),
    meta: opts.meta,
  };
  return order;
}

/** Собирает и сохраняет заказ. */
export async function createOrder(input: OrderInput, opts: CreateOrderOptions = {}): Promise<Order> {
  const order = buildOrder(input, opts);
  await saveOrder(order);
  return order;
}
