/**
 * СДЭК — доставка до пункта выдачи (API v2).
 * Документация: https://api-docs.cdek.ru/
 *
 *   • поиск города          suggestCities("Красн")
 *   • список ПВЗ            getPickupPoints(cityCode)
 *   • расчёт доставки       calculateDelivery({ toCityCode, quantity })
 *   • создание отправления  createShipment({...}) → uuid (после оплаты, из вебхука ЮKassa)
 *   • номер отправления     getTrackingNumber(uuid)
 *
 * Включение: CDEK_ENABLED=true + CDEK_CLIENT_ID + CDEK_CLIENT_SECRET + CDEK_FROM_CITY_CODE (+ CDEK_SHIPMENT_POINT).
 * Для тестов: CDEK_TEST_MODE=true — запросы идут в учебную среду api.edu.cdek.ru.
 */
import { PRODUCT } from "@/config/site";

const BASE = () =>
  (
    process.env.CDEK_API_URL ||
    (process.env.CDEK_TEST_MODE === "true" ? "https://api.edu.cdek.ru/v2" : "https://api.cdek.ru/v2")
  ).replace(/\/$/, "");

/**
 * Упаковка одного мела: 7 × 7 × 1 см, 23 г.
 * Несколько штук складываются стопкой — растёт высота и вес.
 */
export const PACKAGE = {
  /** Вес одной штуки в упаковке, г */
  itemWeight: Number(process.env.CDEK_ITEM_WEIGHT_G || 23),
  /** Дополнительный вес коробки/пакета на всю посылку, г */
  boxWeight: Number(process.env.CDEK_BOX_WEIGHT_G || 0),
  /** Габариты одной штуки, см */
  length: Number(process.env.CDEK_ITEM_LENGTH_CM || 7),
  width: Number(process.env.CDEK_ITEM_WIDTH_CM || 7),
  height: Number(process.env.CDEK_ITEM_HEIGHT_CM || 1),
};

/** Тариф «Посылка склад-склад» (от ПВЗ отправителя до ПВЗ получателя). */
export const DEFAULT_TARIFF = () => Number(process.env.CDEK_TARIFF_CODE || 136);

let token: { value: string; expiresAt: number; base: string } | null = null;

async function getToken(): Promise<string> {
  const base = BASE();
  if (token && token.base === base && token.expiresAt > Date.now() + 60_000) return token.value;
  const id = process.env.CDEK_CLIENT_ID;
  const secret = process.env.CDEK_CLIENT_SECRET;
  if (!id || !secret) throw new Error("СДЭК не настроен (CDEK_CLIENT_ID / CDEK_CLIENT_SECRET)");
  const res = await fetch(`${base}/oauth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "client_credentials", client_id: id, client_secret: secret }),
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  const data = (await res.json().catch(() => ({}))) as { access_token?: string; expires_in?: number };
  if (!res.ok || !data.access_token) throw new Error(`СДЭК: не удалось авторизоваться (HTTP ${res.status})`);
  token = { value: data.access_token, expiresAt: Date.now() + (data.expires_in ?? 3600) * 1000, base };
  return token.value;
}

export class CdekError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(BASE() + path, {
    ...init,
    headers: {
      Authorization: `Bearer ${await getToken()}`,
      "Content-Type": "application/json",
      ...(init.headers as Record<string, string> | undefined),
    },
    cache: "no-store",
    signal: AbortSignal.timeout(15_000),
  });
  const text = await res.text();
  let data: (T & { errors?: { code?: string; message: string }[] }) | undefined;
  try {
    data = text ? JSON.parse(text) : undefined;
  } catch {
    /* не JSON */
  }
  if (!res.ok || !data) {
    const msg = data?.errors?.map((e) => e.message).join("; ") || text.slice(0, 200) || "ошибка";
    throw new CdekError(`СДЭК ${res.status}: ${msg}`, res.status);
  }
  return data;
}

const phoneForCdek = (phone: string) => "+" + phone.replace(/\D/g, "");

/* ───────────────────────── Города ───────────────────────── */

export interface CdekCity {
  code: number;
  /** «Краснодар, Краснодарский край» */
  name: string;
}

/** Подсказки городов для поля ввода. */
export async function suggestCities(query: string): Promise<CdekCity[]> {
  try {
    const q = new URLSearchParams({ name: query, country_code: "RU" });
    const list = await api<Array<{ code: number; full_name?: string; city?: string; region?: string }>>(
      `/location/suggest/cities?${q}`,
    );
    return list
      .filter((c) => Number.isInteger(c.code))
      .slice(0, 10)
      .map((c) => ({ code: c.code, name: (c.full_name ?? [c.city, c.region].filter(Boolean).join(", ")).replace(/, Россия$/, "") }));
  } catch (err) {
    // Запасной вариант — справочник городов
    if (err instanceof CdekError && err.status >= 500) throw err;
    const q = new URLSearchParams({ city: query, country_codes: "RU", size: "10" });
    const list = await api<Array<{ code: number; city: string; region?: string }>>(`/location/cities?${q}`);
    return list.map((c) => ({ code: c.code, name: [c.city, c.region].filter(Boolean).join(", ") }));
  }
}

/* ───────────────────────── Пункты выдачи ───────────────────────── */

export interface CdekPickupPoint {
  code: string;
  name: string;
  address: string;
  workTime?: string;
  latitude?: number;
  longitude?: number;
}

type RawPoint = {
  code: string;
  name: string;
  work_time?: string;
  location: {
    city_code?: number;
    address_full?: string;
    address?: string;
    latitude?: number;
    longitude?: number;
  };
};

const toPoint = (p: RawPoint): CdekPickupPoint => ({
  code: p.code,
  name: p.name,
  address: p.location?.address ?? p.location?.address_full ?? "",
  workTime: p.work_time,
  latitude: p.location?.latitude,
  longitude: p.location?.longitude,
});

const pointsCache = new Map<number, { at: number; points: CdekPickupPoint[] }>();

export async function getPickupPoints(cityCode: number): Promise<CdekPickupPoint[]> {
  const cached = pointsCache.get(cityCode);
  if (cached && Date.now() - cached.at < 30 * 60 * 1000) return cached.points;
  const q = new URLSearchParams({ city_code: String(cityCode), type: "PVZ", is_handout: "true" });
  const list = await api<RawPoint[]>(`/deliverypoints?${q}`);
  const points = list.map(toPoint).sort((a, b) => a.address.localeCompare(b.address, "ru"));
  if (pointsCache.size > 200) pointsCache.clear();
  pointsCache.set(cityCode, { at: Date.now(), points });
  return points;
}

/** Проверяет, что ПВЗ существует, выдаёт посылки и находится в этом городе. */
export async function findPickupPoint(cityCode: number, code: string): Promise<CdekPickupPoint | null> {
  const list = await api<RawPoint[]>(`/deliverypoints?${new URLSearchParams({ code })}`);
  const p = list.find((x) => x.code === code);
  if (!p) return null;
  if (p.location?.city_code && p.location.city_code !== cityCode) return null;
  return toPoint(p);
}

/* ───────────────────────── Расчёт ───────────────────────── */

export const packageFor = (quantity: number) => ({
  weight: Math.max(1, Math.round(PACKAGE.boxWeight + PACKAGE.itemWeight * quantity)),
  length: Math.max(1, Math.ceil(PACKAGE.length)),
  width: Math.max(1, Math.ceil(PACKAGE.width)),
  height: Math.max(1, Math.ceil(PACKAGE.height * quantity)),
});

export interface CdekQuote {
  /** Стоимость доставки по тарифу, ₽ (округлена вверх до рубля) */
  cost: number;
  periodMin: number;
  periodMax: number;
  tariffCode: number;
}

export async function calculateDelivery({
  toCityCode,
  quantity,
  tariffCode = DEFAULT_TARIFF(),
}: {
  toCityCode: number;
  quantity: number;
  tariffCode?: number;
}): Promise<CdekQuote> {
  const fromCode = Number(process.env.CDEK_FROM_CITY_CODE || 0);
  if (!fromCode) throw new Error("Укажите CDEK_FROM_CITY_CODE — код города отправки");
  const data = await api<{ total_sum: number; period_min: number; period_max: number }>("/calculator/tariff", {
    method: "POST",
    body: JSON.stringify({
      tariff_code: tariffCode,
      from_location: { code: fromCode },
      to_location: { code: toCityCode },
      packages: [packageFor(quantity)],
    }),
  });
  return {
    cost: Math.ceil(Number(data.total_sum) || 0),
    periodMin: data.period_min,
    periodMax: data.period_max,
    tariffCode,
  };
}

/* ───────────────────────── Отправления ───────────────────────── */

export interface ShipmentInput {
  orderId: string;
  quantity: number;
  unitPrice: number;
  pickupPointCode: string;
  tariffCode?: number;
  recipient: { name: string; phone: string; email?: string };
}

/** Ищет уже созданное отправление по номеру заказа — чтобы не создать дубль. */
export async function findShipment(orderId: string): Promise<{ uuid: string; trackingNumber: string | null } | null> {
  try {
    const data = await api<{ entity?: { uuid: string; cdek_number?: string } }>(
      `/orders?${new URLSearchParams({ im_number: orderId })}`,
    );
    return data.entity?.uuid ? { uuid: data.entity.uuid, trackingNumber: data.entity.cdek_number ?? null } : null;
  } catch (err) {
    if (err instanceof CdekError && (err.status === 404 || err.status === 400)) return null;
    throw err;
  }
}

/** Создаёт отправление в СДЭК (заказ уже оплачен онлайн). Возвращает UUID заказа СДЭК. */
export async function createShipment(input: ShipmentInput): Promise<string> {
  const shipmentPoint = process.env.CDEK_SHIPMENT_POINT;
  if (!shipmentPoint) throw new Error("Укажите CDEK_SHIPMENT_POINT — код ПВЗ, где вы сдаёте посылки");
  const pkg = packageFor(input.quantity);
  const data = await api<{ entity?: { uuid: string } }>("/orders", {
    method: "POST",
    body: JSON.stringify({
      type: 1, // интернет-магазин
      number: input.orderId,
      tariff_code: input.tariffCode ?? DEFAULT_TARIFF(),
      shipment_point: shipmentPoint,
      delivery_point: input.pickupPointCode,
      delivery_recipient_cost: { value: 0 }, // доставка оплачена на сайте
      recipient: {
        name: input.recipient.name,
        ...(input.recipient.email ? { email: input.recipient.email } : {}),
        phones: [{ number: phoneForCdek(input.recipient.phone) }],
      },
      packages: [
        {
          number: "1",
          ...pkg,
          items: [
            {
              name: PRODUCT.name,
              ware_key: PRODUCT.sku,
              payment: { value: 0 }, // товар оплачен онлайн
              cost: input.unitPrice,
              weight: PACKAGE.itemWeight,
              amount: input.quantity,
            },
          ],
        },
      ],
    }),
  });
  if (!data.entity?.uuid) throw new Error("СДЭК не вернул UUID заказа");
  return data.entity.uuid;
}

/** Номер отправления (трек-номер) появляется через несколько секунд после регистрации заказа в СДЭК. */
export async function getTrackingNumber(orderUuid: string): Promise<string | null> {
  const data = await api<{ entity?: { cdek_number?: string } }>(`/orders/${encodeURIComponent(orderUuid)}`);
  return data.entity?.cdek_number ?? null;
}

/** Ждёт трек-номер до ~waitMs миллисекунд. */
export async function waitForTrackingNumber(orderUuid: string, waitMs = 8_000): Promise<string | null> {
  const until = Date.now() + waitMs;
  for (;;) {
    try {
      const n = await getTrackingNumber(orderUuid);
      if (n) return n;
    } catch {
      /* регистрация ещё идёт */
    }
    if (Date.now() + 2_000 > until) return null;
    await new Promise((r) => setTimeout(r, 2_000));
  }
}
