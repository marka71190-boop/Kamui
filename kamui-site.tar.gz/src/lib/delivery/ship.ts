/**
 * После успешной оплаты: создаём отправление СДЭК и дописываем трек-номер в таблицу.
 * Данные о получателе и ПВЗ берутся из metadata платежа ЮKassa.
 */
import { updateOrder } from "@/lib/orders/store";
import type { YooKassaPayment } from "@/lib/payments/yookassa";
import { createShipment, findShipment, waitForTrackingNumber } from "./cdek";

export async function shipPaidOrder(payment: YooKassaPayment): Promise<void> {
  const m = payment.metadata ?? {};
  const orderId = m.orderId;
  if (!orderId || !m.pvz) return;
  const base = m.delivery || `СДЭК ПВЗ ${m.pvz}`;

  try {
    let shipment = await findShipment(orderId);
    if (!shipment) {
      const uuid = await createShipment({
        orderId,
        quantity: Number(m.qty) || 1,
        unitPrice: Number(m.price) || 0,
        pickupPointCode: m.pvz,
        tariffCode: m.tariff ? Number(m.tariff) : undefined,
        recipient: { name: m.name ?? "", phone: m.phone ?? "", email: m.email },
      });
      shipment = { uuid, trackingNumber: null };
    }
    const tracking = shipment.trackingNumber ?? (await waitForTrackingNumber(shipment.uuid));
    await updateOrder(orderId, {
      delivery: {
        provider: "cdek",
        label: tracking ? `${base} · трек ${tracking}` : `${base} · отправление создано в СДЭК`,
        cdek: { pickupPointCode: m.pvz, orderUuid: shipment.uuid, trackingNumber: tracking ?? undefined },
      },
    });
  } catch (err) {
    console.error(`[cdek] Не удалось создать отправление для ${orderId}:`, err);
    await updateOrder(orderId, {
      delivery: {
        provider: "cdek",
        label: `${base} · ⚠ отправление не создано автоматически — оформите в личном кабинете СДЭК`,
        cdek: { pickupPointCode: m.pvz },
      },
    });
  }
}
