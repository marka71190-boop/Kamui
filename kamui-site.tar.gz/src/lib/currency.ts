/**
 * Цена в долларах для английской версии сайта.
 *   PRICE_USD=45        — фиксированная цена за 1 шт.;
 *   иначе               — рубли / курс ЦБ РФ (обновляется раз в час), округление вверх до доллара;
 *   если ЦБ недоступен  — курс USD_RATE_FALLBACK (по умолчанию 90).
 */
import { PRODUCT } from "@/config/site";

export interface UsdPrice {
  /** Цена 1 шт., $ */
  unit: number;
  /** Курс ₽ за $ (null — цена задана вручную) */
  rate: number | null;
  source: "fixed" | "cbr" | "fallback";
}

export async function getUsdPrice(): Promise<UsdPrice> {
  const fixed = Number(process.env.PRICE_USD);
  if (Number.isFinite(fixed) && fixed > 0) return { unit: Math.round(fixed), rate: null, source: "fixed" };
  try {
    const res = await fetch("https://www.cbr-xml-daily.ru/daily_json.js", {
      next: { revalidate: 3600 },
      signal: AbortSignal.timeout(5_000),
    });
    const data = JSON.parse(await res.text()) as { Valute?: { USD?: { Value?: number } } };
    const rate = Number(data.Valute?.USD?.Value);
    if (rate > 10 && rate < 1000) return { unit: Math.ceil(PRODUCT.price / rate), rate, source: "cbr" };
  } catch (err) {
    console.warn("[currency] Курс ЦБ недоступен:", (err as Error).message);
  }
  const fb = Number(process.env.USD_RATE_FALLBACK || 90);
  return { unit: Math.ceil(PRODUCT.price / fb), rate: fb, source: "fallback" };
}
