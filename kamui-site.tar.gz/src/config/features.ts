/**
 * Флаги интеграций. Всё выключено, пока не заданы ключи в переменных окружения.
 * Серверный модуль — не импортируйте его в клиентские компоненты
 * (в браузер передаётся только checkoutConfig()).
 */

const on = (v: string | undefined) => v === "true" || v === "1";

export const features = {
  /** Google Таблица с заказами (Apps Script веб-приложение) */
  get googleSheets() {
    return Boolean(process.env.GOOGLE_SHEETS_WEBHOOK_URL && process.env.GOOGLE_SHEETS_SECRET);
  },
  /** Локальная копия заявок в data/orders.jsonl (по умолчанию включена) */
  get fileStore() {
    return process.env.ORDERS_FILE_STORE !== "false";
  },
  /** Онлайн-оплата через ЮKassa */
  get payments() {
    return on(process.env.PAYMENTS_ENABLED) && Boolean(process.env.YOOKASSA_SHOP_ID && process.env.YOOKASSA_SECRET_KEY);
  },
  /** Доставка СДЭК (ПВЗ, расчёт, создание отправлений) */
  get cdek() {
    return on(process.env.CDEK_ENABLED) && Boolean(process.env.CDEK_CLIENT_ID && process.env.CDEK_CLIENT_SECRET);
  },
  /**
   * Кто платит за доставку СДЭК:
   *   customer — покупатель, стоимость по тарифу СДЭК добавляется к заказу (по умолчанию);
   *   free     — продавец, для покупателя доставка бесплатная.
   */
  get freeDelivery() {
    return process.env.DELIVERY_PRICE_MODE === "free";
  },
  /**
   * Подключён тестовый магазин ЮKassa (секретный ключ начинается с test_).
   * Тогда оплата видна только по секретной ссылке ?paytest=<PAYMENTS_TEST_TOKEN>,
   * а обычные покупатели по-прежнему оставляют заявку без оплаты.
   */
  get paymentsTestShop() {
    return (process.env.YOOKASSA_SECRET_KEY ?? "").startsWith("test_");
  },
  /** Наценка к тарифу СДЭК для покупателя, % (DELIVERY_MARKUP_PERCENT, например 30). */
  get deliveryMarkupPercent() {
    const n = Number(process.env.DELIVERY_MARKUP_PERCENT || 0);
    return Number.isFinite(n) && n > 0 ? n : 0;
  },
  /** После оплаты автоматически создавать отправление в СДЭК (по умолчанию — да). */
  get cdekAutoShipment() {
    return process.env.CDEK_AUTO_SHIPMENT !== "false";
  },
};

/** Настройки оформления заказа, которые нужны браузеру. */
export interface CheckoutConfig {
  /** Выбор ПВЗ СДЭК и расчёт доставки в форме */
  cdek: boolean;
  /** Онлайн-оплата сразу после оформления (для заказов по России) */
  payments: boolean;
  /** Подключён тестовый магазин: оплата только по секретной ссылке */
  paymentsTest: boolean;
  /** Доставка бесплатная для покупателя */
  freeDelivery: boolean;
}

export function checkoutConfig(): CheckoutConfig {
  const payments = features.payments;
  return {
    cdek: features.cdek,
    payments: payments && !features.paymentsTestShop,
    paymentsTest: payments && features.paymentsTestShop,
    freeDelivery: features.freeDelivery,
  };
}
