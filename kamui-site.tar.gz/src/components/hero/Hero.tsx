import { galleryFor } from "@/config/gallery";
import { t } from "@/i18n/dict";
import { RU_MARKET, type Market } from "@/i18n/market";
import { formatMoney } from "@/lib/format";
import type { StockView } from "@/lib/stock";
import { Signature } from "@/components/signature/Signature";
import { Slider } from "@/components/slider/Slider";
import { ArrowRight } from "@/components/ui/Icons";
import { LiveStockMeter } from "@/components/stock/LiveStockMeter";
import styles from "./Hero.module.css";

export function Hero({ stock, market = RU_MARKET }: { stock: StockView; market?: Market }) {
  const lang = market.lang;
  const tx = t(lang).hero;
  return (
    <section className={styles.hero} aria-labelledby="hero-title">
      <div className={styles.media}>
        <Slider
          slides={galleryFor(lang)}
          variant="hero"
          lang={lang}
          ariaLabel={tx.sliderAria}
          sizes="(max-width: 1023px) 100vw, 60vw"
          autoPlay={6500}
          priority
        />
        <div className={styles.shade} aria-hidden="true" />
      </div>

      <div className={`container ${styles.content}`}>
        <p className={styles.eyebrow}>
          <span>{tx.eyebrow}</span>
          <span className={styles.eyebrowDot} aria-hidden="true" />
          <span>{tx.pieces(stock.total)}</span>
        </p>

        <div className={styles.titleBlock}>
          <h1 id="hero-title" className={styles.title}>
            <span className={styles.line}>
              Kamui <span className={styles.x}>×</span>
            </span>
            <span className={styles.line}>Iosif Abramov</span>
            <span className="visually-hidden"> — </span>
            <span className={styles.edition}>Limited Edition</span>
            <span className={styles.model}>0.98 β</span>
          </h1>
          <div className={styles.signature}>
            <Signature trigger="mount" delay={1100} duration={3600} lang={lang} />
          </div>
        </div>

        <div className={styles.cta}>
          <a href="#buy" className="btn">
            {tx.cta}
            <ArrowRight className="btn__arrow" />
          </a>
          <p className={styles.price}>
            <span>{tx.price}</span>
            <b>{formatMoney(market.unitPrice, market.currency)}</b>
          </p>
        </div>

        <LiveStockMeter stock={stock} compact className={styles.stock} lang={lang} />
      </div>
    </section>
  );
}
