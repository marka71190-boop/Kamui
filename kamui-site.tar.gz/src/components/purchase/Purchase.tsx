import Image from "next/image";
import { checkoutConfig } from "@/config/features";
import { galleryFor } from "@/config/gallery";
import { t } from "@/i18n/dict";
import { RU_MARKET, type Market } from "@/i18n/market";
import type { StockView } from "@/lib/stock";
import { OrderPanel } from "./OrderPanel";
import styles from "./Purchase.module.css";

export function Purchase({ stock, market = RU_MARKET }: { stock: StockView; market?: Market }) {
  const lang = market.lang;
  const tx = t(lang).purchase;
  const photo = galleryFor(lang)[1];
  // Английская версия — только заявки из-за рубежа: без СДЭК и онлайн-оплаты ЮKassa
  const checkout =
    lang === "en" ? { ...checkoutConfig(), cdek: false, payments: false, paymentsTest: false } : checkoutConfig();
  return (
    <section id="buy" className={`section ${styles.purchase}`} aria-labelledby="buy-title">
      <div className="container">
        <p className="section-label" data-reveal>
          <b>05</b> {tx.label}
        </p>
        <h2 id="buy-title" className="section-title" data-reveal>
          {tx.title}
        </h2>

        <div className={styles.layout} data-reveal>
          <div className={styles.visual}>
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              sizes="(max-width: 960px) 100vw, 42vw"
              placeholder="blur"
              className={styles.visualImg}
            />
            <div className={styles.visualShade} aria-hidden="true" />
            <div className={styles.visualCaption}>
              <span className={styles.badge}>Limited Edition</span>
              <p className={styles.visualModel}>0.98 β</p>
            </div>
          </div>
          <OrderPanel stock={stock} checkout={checkout} market={market} />
        </div>
      </div>
    </section>
  );
}
