"use client";

import { Minus, Plus } from "@/components/ui/Icons";
import { t } from "@/i18n/dict";
import type { Lang } from "@/i18n/lang";
import styles from "./Purchase.module.css";

interface Props {
  value: number;
  min?: number;
  max: number;
  onChange: (v: number) => void;
  labelledBy: string;
  disabled?: boolean;
  lang?: Lang;
}

/** [-] 1 [+] */
export function QuantityStepper({ value, min = 1, max, onChange, labelledBy, disabled, lang = "ru" }: Props) {
  const tx = t(lang).qty;
  return (
    <div className={styles.stepper} role="group" aria-labelledby={labelledBy}>
      <button
        type="button"
        className={styles.stepBtn}
        onClick={() => onChange(Math.max(min, value - 1))}
        disabled={disabled || value <= min}
        aria-label={tx.less}
      >
        <Minus />
      </button>
      <output className={styles.stepValue} aria-live="polite" aria-label={tx.pcs(value)}>
        {value}
      </output>
      <button
        type="button"
        className={styles.stepBtn}
        onClick={() => onChange(Math.min(max, value + 1))}
        disabled={disabled || value >= max}
        aria-label={tx.more}
      >
        <Plus />
      </button>
    </div>
  );
}
