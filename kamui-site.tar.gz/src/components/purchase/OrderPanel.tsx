"use client";

import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import Link from "next/link";
import type { CheckoutConfig } from "@/config/features";
import { PRODUCT } from "@/config/site";
import { t } from "@/i18n/dict";
import { RU_MARKET, type Market } from "@/i18n/market";
import { formatMoney } from "@/lib/format";
import { toLatin } from "@/lib/translit";
import {
  formatRuPhoneInput,
  LIMITS,
  normalizeOrderInput,
  validateOrderInput,
  type FieldErrors,
  type OrderField,
  type OrderInput,
} from "@/lib/orders/validation";
import type { StockView } from "@/lib/stock";
import { useLiveStock } from "@/components/stock/LiveStock";
import { ArrowRight, Check } from "@/components/ui/Icons";
import { StockMeter } from "@/components/ui/StockMeter";
import { CdekPicker, type CdekSelection, type QuoteState } from "./CdekPicker";
import { PaymentResult, rememberPayment } from "./PaymentResult";
import { QuantityStepper } from "./QuantityStepper";
import styles from "./Purchase.module.css";

type Stage = "intro" | "form" | "success" | "payment";

type Fields = Omit<OrderInput, "quantity" | "region" | "payTest" | "lang">;

const PAYTEST_KEY = "kamui:paytest";

/** Токен тестовой оплаты: из ссылки ?paytest=… (запоминается на время вкладки). */
function readPayTestToken(): string {
  try {
    const url = new URL(window.location.href);
    const fromUrl = url.searchParams.get("paytest");
    if (fromUrl) {
      sessionStorage.setItem(PAYTEST_KEY, fromUrl.slice(0, 64));
      url.searchParams.delete("paytest");
      window.history.replaceState(null, "", url.pathname + url.search + url.hash);
      return fromUrl.slice(0, 64);
    }
    return sessionStorage.getItem(PAYTEST_KEY) ?? "";
  } catch {
    return "";
  }
}

const EMPTY: Fields = {
  name: "",
  phone: "",
  email: "",
  city: "",
  comment: "",
  country: "",
  postalCode: "",
  address: "",
  consent: false,
  cityCode: 0,
  pickupPoint: "",
  company: "",
};

/** Порядок полей — для фокуса на первой ошибке */
const FIELD_ORDER: OrderField[] = [
  "quantity",
  "name",
  "phone",
  "email",
  "country",
  "city",
  "pickupPoint",
  "postalCode",
  "address",
  "comment",
  "consent",
];

export function OrderPanel({
  stock: initialStock,
  checkout,
  market = RU_MARKET,
}: {
  stock: StockView;
  checkout: CheckoutConfig;
  market?: Market;
}) {
  const stock = useLiveStock(initialStock);
  const lang = market.lang;
  const tx = t(lang).order;
  const money = (v: number) => formatMoney(v, market.currency);
  const maxQuantity = Math.max(0, Math.min(PRODUCT.maxPerOrder, stock.remaining));
  const soldOut = maxQuantity === 0;

  const [stage, setStage] = useState<Stage>("intro");
  const [quantity, setQuantity] = useState(1);
  const [region, setRegion] = useState<OrderInput["region"]>(lang === "en" ? "intl" : "ru");
  const [fields, setFields] = useState<Fields>(EMPTY);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");
  const [orderId, setOrderId] = useState("");
  const [successText, setSuccessText] = useState(tx.successText);
  const [quote, setQuote] = useState<QuoteState>({ state: "idle" });
  const [payTest, setPayTest] = useState("");
  const [payMethods, setPayMethods] = useState<string[]>([]);
  const rootRef = useRef<HTMLDivElement>(null);
  const firstFieldRef = useRef<HTMLInputElement>(null);

  // Тестовая оплата по секретной ссылке + возврат со страницы оплаты ЮKassa: /?order=KA-...#buy
  useEffect(() => {
    const token = checkout.paymentsTest ? readPayTestToken() : "";
    setPayTest(token);
    const id = new URLSearchParams(window.location.search).get("order");
    if (id && /^KA-\d{6}-[A-Z0-9]{4}$/.test(id)) {
      setOrderId(id);
      setStage(checkout.payments || token ? "payment" : "success");
    }
  }, [checkout.payments, checkout.paymentsTest]);

  /** Онлайн-оплата включена для этого посетителя */
  const paymentsOn = checkout.payments || (checkout.paymentsTest && payTest !== "");

  // Способы оплаты, подключённые в ЮKassa, — для подписи у кнопки
  useEffect(() => {
    if (!paymentsOn) return;
    const ctrl = new AbortController();
    fetch("/api/payments/methods", { signal: ctrl.signal })
      .then((r) => r.json())
      .then((d: { methods?: string[] }) => setPayMethods(Array.isArray(d.methods) ? d.methods : []))
      .catch(() => {});
    return () => ctrl.abort();
  }, [paymentsOn]);
  const useCdek = checkout.cdek && region === "ru";
  const payOnline = paymentsOn && region === "ru";
  const rules = (r: OrderInput["region"]) => ({ maxQuantity, requirePickupPoint: checkout.cdek && r === "ru" });

  const input = (): OrderInput => normalizeOrderInput({ ...fields, quantity, region, payTest, lang });

  const revalidate = (next: Partial<Fields> = {}, nextRegion = region, nextQty = quantity) => {
    if (!submitted) return;
    setErrors(
      validateOrderInput(
        normalizeOrderInput({ ...fields, ...next, region: nextRegion, quantity: nextQty, lang }),
        rules(nextRegion),
      ),
    );
  };

  const set =
    <K extends keyof Fields>(key: K) =>
    (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      let value: Fields[K];
      if (key === "consent") value = (e.target as HTMLInputElement).checked as Fields[K];
      else if (key === "phone" && region === "ru") value = formatRuPhoneInput(e.target.value) as Fields[K];
      // Для отправки за рубеж ФИО нужно латиницей — переводим сразу при вводе
      else if (key === "name" && region === "intl") value = toLatin(e.target.value) as Fields[K];
      else value = e.target.value as Fields[K];
      setFields((f) => ({ ...f, [key]: value }));
      revalidate({ [key]: value } as Partial<Fields>);
    };

  const changeCdek = (sel: CdekSelection) => {
    setFields((f) => ({ ...f, ...sel }));
    revalidate(sel);
  };

  const changeQuantity = (q: number) => {
    setQuantity(q);
    revalidate({}, region, q);
  };

  const toggleRegion = (e: ChangeEvent<HTMLInputElement>) => {
    const next = e.target.checked ? "intl" : "ru";
    setRegion(next);
    if (next === "intl") setFields((f) => ({ ...f, name: toLatin(f.name) }));
    revalidate(next === "intl" ? { name: toLatin(fields.name) } : {}, next);
  };

  const openForm = () => {
    setStage("form");
    window.setTimeout(() => firstFieldRef.current?.focus({ preventScroll: true }), 450);
  };

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (stage !== "form" || submitting) return;
    setSubmitted(true);
    setServerError("");

    const data = input();
    const errs = validateOrderInput(data, rules(data.region));
    setErrors(errs);
    const firstInvalid = FIELD_ORDER.find((f) => errs[f]);
    if (firstInvalid) {
      rootRef.current?.querySelector<HTMLElement>(`[data-field="${firstInvalid}"]`)?.focus();
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const body = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        orderId?: string;
        paymentId?: string;
        paymentUrl?: string;
        paymentUnavailable?: boolean;
        error?: string;
        fieldErrors?: FieldErrors;
      };
      if (res.ok && body.ok && body.orderId) {
        if (body.paymentUrl) {
          if (body.paymentId) rememberPayment(body.orderId, body.paymentId);
          window.location.assign(body.paymentUrl);
          return;
        }
        setSuccessText(body.paymentUnavailable ? tx.noPaymentText : tx.successText);
        setOrderId(body.orderId);
        setStage("success");
        setFields(EMPTY);
        setSubmitted(false);
        rootRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      } else {
        if (body.fieldErrors) setErrors(body.fieldErrors);
        setServerError(body.error || tx.failed);
      }
    } catch {
      setServerError(tx.offline);
    } finally {
      setSubmitting(false);
    }
  };

  const total = market.unitPrice * quantity;
  const formOpen = stage === "form";
  const deliveryCost = useCdek && quote.state === "ready" ? (checkout.freeDelivery ? 0 : quote.quote.cost) : 0;
  const grandTotal = total + deliveryCost;

  const resetAfterReturn = () => {
    setStage("intro");
    setOrderId("");
    if (window.location.search) window.history.replaceState(null, "", window.location.pathname + "#buy");
  };

  if (stage === "payment") {
    return (
      <div ref={rootRef} className={styles.panel}>
        <PaymentResult orderId={orderId} onReset={resetAfterReturn} />
      </div>
    );
  }

  if (stage === "success") {
    return (
      <div ref={rootRef} className={styles.success} role="status" aria-live="polite">
        <span className={styles.successIcon} aria-hidden="true">
          <Check />
        </span>
        <p className={styles.successTitle}>{tx.successTitle}</p>
        <p className={styles.successText}>{successText}</p>
        {orderId && (
          <p className={styles.orderId}>
            {tx.orderNumber} <b>{orderId}</b>
          </p>
        )}
        <button
          type="button"
          className="btn btn--ghost"
          onClick={resetAfterReturn}
        >
          {tx.again}
        </button>
      </div>
    );
  }

  const err = (f: OrderField) => errors[f];
  const a11y = (f: OrderField) => ({
    "data-field": f,
    "aria-invalid": err(f) ? true : undefined,
    "aria-describedby": err(f) ? `${f}-error` : undefined,
  });

  return (
    <div ref={rootRef} className={styles.panel}>
      <form onSubmit={onSubmit} noValidate aria-label={tx.formAria} lang={lang}>
        <div className={styles.summary}>
          <div>
            <p className={styles.productName}>Kamui × Iosif Abramov</p>
            <p className={styles.productSub}>Limited Edition 0.98 β</p>
          </div>
          <p className={styles.bigPrice}>
            {money(market.unitPrice)}
            <span>{tx.perPiece}</span>
          </p>
        </div>

        <StockMeter stock={stock} compact className={styles.stock} lang={lang} />

        <div className={styles.qtyRow}>
          <span id="qty-label" className={styles.qtyLabel}>
            {tx.quantity}
          </span>
          <QuantityStepper
            value={quantity}
            max={Math.max(1, maxQuantity)}
            onChange={changeQuantity}
            labelledBy="qty-label"
            disabled={soldOut}
            lang={lang}
          />
          <p className={styles.total}>
            <span>{formOpen && (useCdek || payOnline) ? tx.goods : tx.total}</span>
            <b>{money(total)}</b>
          </p>
        </div>
        {err("quantity") && (
          <p id="quantity-error" className={styles.error} role="alert">
            {err("quantity")}
          </p>
        )}

        {!formOpen && (
          <div className={styles.introCta}>
            <button
              type="button"
              className="btn btn--block"
              onClick={openForm}
              disabled={soldOut}
              aria-controls="order-fields"
              aria-expanded={false}
            >
              {soldOut ? tx.soldOut : paymentsOn ? tx.placeOrder : tx.request}
              {!soldOut && <ArrowRight className="btn__arrow" />}
            </button>
            <p className={styles.note}>
              {paymentsOn ? tx.notePay(payMethods) : tx.noteRequest}
            </p>
          </div>
        )}

        <div id="order-fields" className={styles.collapse} data-open={formOpen || undefined}>
          <div className={styles.collapseInner} inert={!formOpen}>
            <div className={styles.fields}>
              {lang === "ru" && (
                <label className={styles.switch}>
                  <input type="checkbox" role="switch" checked={region === "intl"} onChange={toggleRegion} />
                  <span className={styles.switchTrack} aria-hidden="true" />
                  <span>{tx.abroad}</span>
                </label>
              )}

              <Field
                id="name"
                label={region === "intl" ? tx.nameLatin : tx.name}
                hint={region === "intl" ? tx.nameLatinHint : tx.nameHint}
                error={err("name")}
                required
                wide
              >
                <input
                  ref={firstFieldRef}
                  id="name"
                  name="name"
                  autoComplete="name"
                  maxLength={LIMITS.name}
                  value={fields.name}
                  onChange={set("name")}
                  placeholder={region === "intl" ? tx.nameLatinPlaceholder : tx.namePlaceholder}
                  autoCapitalize="words"
                  spellCheck={false}
                  {...a11y("name")}
                />
              </Field>

              <Field id="phone" label={tx.phone} error={err("phone")} required>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  maxLength={LIMITS.phone}
                  value={fields.phone}
                  onChange={set("phone")}
                  placeholder={region === "ru" ? "+7 (999) 123-45-67" : "+49 30 1234567"}
                  {...a11y("phone")}
                />
              </Field>

              <Field id="email" label={tx.email} error={err("email")} required>
                <input
                  id="email"
                  name="email"
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  maxLength={LIMITS.email}
                  value={fields.email}
                  onChange={set("email")}
                  placeholder="you@example.com"
                  {...a11y("email")}
                />
              </Field>

              {region === "intl" && (
                <Field id="country" label={tx.country} error={err("country")} required>
                  <input
                    id="country"
                    name="country"
                    autoComplete="country-name"
                    maxLength={LIMITS.country}
                    value={fields.country}
                    onChange={set("country")}
                    placeholder={tx.countryPlaceholder}
                    {...a11y("country")}
                  />
                </Field>
              )}

              {useCdek ? (
                <CdekPicker
                  value={{ city: fields.city, cityCode: fields.cityCode, pickupPoint: fields.pickupPoint }}
                  quantity={quantity}
                  freeDelivery={checkout.freeDelivery}
                  cityError={err("city")}
                  pointError={err("pickupPoint")}
                  onChange={changeCdek}
                  onQuote={setQuote}
                />
              ) : (
                <Field id="city" label={tx.city} error={err("city")} required>
                  <input
                    id="city"
                    name="city"
                    autoComplete="address-level2"
                    maxLength={LIMITS.city}
                    value={fields.city}
                    onChange={set("city")}
                    placeholder={region === "ru" ? tx.cityPlaceholderRu : tx.cityPlaceholderIntl}
                    {...a11y("city")}
                  />
                </Field>
              )}

              {region === "intl" && (
                <>
                  <Field id="postalCode" label={tx.postalCode} error={err("postalCode")} required>
                    <input
                      id="postalCode"
                      name="postalCode"
                      autoComplete="postal-code"
                      maxLength={LIMITS.postalCode}
                      value={fields.postalCode}
                      onChange={set("postalCode")}
                      placeholder={tx.postalPlaceholder}
                      {...a11y("postalCode")}
                    />
                  </Field>
                  <Field id="address" label={tx.address} error={err("address")} required wide>
                    <input
                      id="address"
                      name="address"
                      autoComplete="street-address"
                      maxLength={LIMITS.address}
                      value={fields.address}
                      onChange={set("address")}
                      placeholder={tx.addressPlaceholder}
                      {...a11y("address")}
                    />
                  </Field>
                </>
              )}

              <Field id="comment" label={tx.comment} error={err("comment")} wide>
                <textarea
                  id="comment"
                  name="comment"
                  rows={3}
                  maxLength={LIMITS.comment}
                  value={fields.comment}
                  onChange={set("comment")}
                  placeholder={region === "ru" ? tx.commentPlaceholderRu : tx.commentPlaceholderIntl}
                  {...a11y("comment")}
                />
              </Field>

              {/* Ловушка для ботов: скрыта от людей */}
              <div className={styles.hp} aria-hidden="true">
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  tabIndex={-1}
                  autoComplete="off"
                  value={fields.company}
                  onChange={set("company")}
                />
              </div>

              <div className={`${styles.consent} ${styles.wide}`}>
                <label className={styles.checkbox}>
                  <input type="checkbox" checked={fields.consent} onChange={set("consent")} {...a11y("consent")} />
                  <span className={styles.checkboxBox} aria-hidden="true">
                    <Check />
                  </span>
                  <span>
                    {tx.consentBefore}{" "}
                    <Link href="/consent" target="_blank" className={styles.link}>
                      {tx.consentLink}
                    </Link>
                    .{" "}
                    <Link href="/privacy" target="_blank" className={styles.link}>
                      {tx.privacyLink}
                    </Link>
                  </span>
                </label>
                {err("consent") && (
                  <p id="consent-error" className={styles.error} role="alert">
                    {err("consent")}
                  </p>
                )}
              </div>
            </div>

            {(useCdek || payOnline) && (
              <div className={styles.breakdown} aria-live="polite">
                <p className={styles.breakdownRow}>
                  <span>
                    Товар · {quantity} шт.
                  </span>
                  <b>{money(total)}</b>
                </p>
                <p className={styles.breakdownRow}>
                  <span>Доставка СДЭК</span>
                  <b>
                    {!useCdek
                      ? checkout.freeDelivery
                        ? "бесплатно"
                        : "оплачивается при получении"
                      : quote.state === "ready"
                        ? deliveryCost === 0
                          ? "бесплатно"
                          : money(deliveryCost)
                        : quote.state === "loading"
                          ? "считаем…"
                          : quote.state === "error"
                            ? "уточним после заявки"
                            : "выберите город"}
                  </b>
                </p>
                <p className={`${styles.breakdownRow} ${styles.breakdownTotal}`}>
                  <span>{payOnline ? "К оплате" : "Итого"}</span>
                  <b>{money(grandTotal)}</b>
                </p>
              </div>
            )}

            {serverError && (
              <p className={styles.serverError} role="alert">
                {serverError}
              </p>
            )}

            <button type="submit" className="btn btn--block" disabled={submitting}>
              {submitting
                ? payOnline
                  ? tx.toPayment
                  : tx.sending
                : payOnline && !(useCdek && quote.state === "error")
                  ? tx.pay(money(grandTotal))
                  : tx.send(quantity)}
              {!submitting && <ArrowRight className="btn__arrow" />}
            </button>
            {payOnline ? (
              <div className={styles.payNote}>
                <span>
                  Нажимая кнопку, вы принимаете условия{" "}
                  <Link href="/oferta" target="_blank" className={styles.link}>
                    оферты
                  </Link>
                  . Безопасная оплата на странице ЮKassa
                  {checkout.paymentsTest && " · тестовый режим: деньги не списываются"}
                </span>
                <span className={styles.payMethods} aria-label="Способы оплаты">
                  {(payMethods.length > 0 ? payMethods : ["Банковская карта"]).map((m) => (
                    <span key={m}>{m}</span>
                  ))}
                </span>
              </div>
            ) : (
              <p className={styles.note}>
                {region === "ru"
                  ? useCdek
                    ? "Оплата — после подтверждения заявки менеджером. Доставка СДЭК до выбранного пункта выдачи."
                    : "Оплата и доставка — после подтверждения заявки менеджером. Доставляем по России через СДЭК."
                  : tx.noteIntl}
              </p>
            )}
            {tx.otherVersion && (
              <p className={styles.note}>
                {tx.otherVersion.text}{" "}
                <a href={tx.otherVersion.href} hrefLang="ru" className={styles.link}>
                  {tx.otherVersion.link}
                </a>
              </p>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}

function Field({
  id,
  label,
  hint,
  error,
  required,
  wide,
  children,
}: {
  id: string;
  label: string;
  hint?: string;
  error?: string;
  required?: boolean;
  wide?: boolean;
  children: ReactNode;
}) {
  return (
    <div className={`${styles.field} ${wide ? styles.wide : ""}`} data-invalid={error ? "" : undefined}>
      <label htmlFor={id} className={styles.label}>
        {label}
        {required && (
          <span className={styles.req} aria-hidden="true">
            *
          </span>
        )}
      </label>
      {children}
      {hint && !error && <p className={styles.hint}>{hint}</p>}
      {error && (
        <p id={`${id}-error`} className={styles.error} role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
