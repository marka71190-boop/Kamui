import { RU_MARKET, type Market } from "@/i18n/market";
import type { StockView } from "@/lib/stock";
import { LiveStockProvider } from "./stock/LiveStock";
import { Footer } from "./footer/Footer";
import { Header } from "./header/Header";
import { Hero } from "./hero/Hero";
import { Purchase } from "./purchase/Purchase";
import { Collection } from "./sections/Collection";
import { Features } from "./sections/Features";
import { Gallery } from "./sections/Gallery";
import { Story } from "./sections/Story";
import { Marquee } from "./ui/Marquee";
import { RevealObserver } from "./ui/RevealObserver";

export function HomePage({ stock: full, market = RU_MARKET }: { stock: StockView; market?: Market }) {
  const lang = market.lang;
  // В браузер — только цифры для показа
  const stock: StockView = { total: full.total, sold: full.sold, remaining: full.remaining, soldOut: full.soldOut };
  return (
    <LiveStockProvider initial={stock}>
      <Header stock={stock} market={market} />
      <main id="main" lang={lang}>
        <Hero stock={stock} market={market} />
        <Marquee />
        <Collection stock={stock} lang={lang} />
        <Features lang={lang} />
        <Story lang={lang} />
        <Gallery lang={lang} />
        <Purchase stock={stock} market={market} />
      </main>
      <Footer lang={lang} />
      <RevealObserver />
    </LiveStockProvider>
  );
}
