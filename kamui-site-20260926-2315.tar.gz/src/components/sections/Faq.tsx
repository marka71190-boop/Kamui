import { t } from "@/i18n/dict";
import type { Lang } from "@/i18n/lang";
import { revealDelay } from "@/lib/style";
import { Plus } from "@/components/ui/Icons";
import styles from "./Faq.module.css";

/**
 * Вопросы и ответы о меле. Ответы лежат в HTML даже в свёрнутом виде (details/summary),
 * поэтому поисковики видят весь текст. Тот же текст — в разметке FAQPage (src/lib/seo.ts).
 */
export function Faq({ lang = "ru", price }: { lang?: Lang; price: string }) {
  const tx = t(lang).faq;
  const items = tx.items(price);
  return (
    <section id="faq" className={`section ${styles.faq}`} aria-labelledby="faq-title">
      <div className={`container ${styles.grid}`}>
        <div>
          <p className="section-label" data-reveal>
            <b>06</b> {tx.label}
          </p>
          <h2 id="faq-title" className={`section-title ${styles.title}`} data-reveal>
            {tx.title}
          </h2>
        </div>

        <div className={styles.list}>
          {items.map((item, i) => (
            <details key={item.q} className={styles.item} data-reveal style={revealDelay(Math.min(i, 4) * 60)}>
              <summary className={styles.question}>
                <h3>{item.q}</h3>
                <Plus className={styles.icon} />
              </summary>
              <p className={styles.answer}>{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
