import type { MetadataRoute } from "next";
import { SITE } from "@/config/site";

export default function robots(): MetadataRoute.Robots {
  return {
    // Справочники доставки (города, пункты выдачи, расчёт) — публичные данные, их можно открывать.
    // Служебная проверка /pay-check поисковикам не нужна.
    rules: [{ userAgent: "*", allow: ["/", "/api/delivery/"], disallow: ["/api/", "/pay-check"] }],
    sitemap: `${SITE.url}/sitemap.xml`,
    host: SITE.domain,
  };
}
