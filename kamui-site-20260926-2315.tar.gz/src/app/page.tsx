import type { Metadata } from "next";
import { HomePage } from "@/components/HomePage";
import { PRODUCT } from "@/config/site";
import { t } from "@/i18n/dict";
import { formatMoney } from "@/lib/format";
import { faqJsonLd, pageJsonLd, productJsonLd, storeJsonLd, websiteJsonLd } from "@/lib/seo";
import { renderPerRequestOnOwnServer } from "@/lib/render-mode";
import { getStock } from "@/lib/stock";

/** Страница статическая и пересобирается раз в минуту — так остаток всегда свежий. */
export const revalidate = 60;

export const metadata: Metadata = {
  alternates: { canonical: "/", languages: { ru: "/", en: "/en" } },
};

export default async function Page() {
  await renderPerRequestOnOwnServer();
  const stock = await getStock();
  const jsonLd = pageJsonLd([
    productJsonLd(stock),
    storeJsonLd(),
    websiteJsonLd("ru"),
    faqJsonLd(t("ru").faq.items(formatMoney(PRODUCT.price, "RUB"))),
  ]);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd }} />
      <HomePage stock={stock} />
    </>
  );
}
