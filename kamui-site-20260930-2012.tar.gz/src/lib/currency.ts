/**
 * Цены для покупателей из-за рубежа — в долларах.
 *   PRICE_USD=48          — цена за 1 шт. (по умолчанию PRODUCT.priceUsd);
 *   курс ЦБ РФ            — для пересчёта в рубли при оплате (обновляется раз в час);
 *   если ЦБ недоступен    — курс USD_RATE_FALLBACK (по умолчанию 90).
 */
import { PRODUCT } from "@/config/site";

export interface UsdRate {
  /** ₽ за $1 */
  rate: number;
  source: "cbr" | "fallback";
}

export async function getUsdRate(): Promise<UsdRate> {
  try {
    const res = await fetch("https://www.cbr-xml-daily.ru/daily_json.js", {
      next: { revalidate: 3600 },
      signal: AbortSignal.timeout(5_000),
    });
    const data = JSON.parse(await res.text()) as { Valute?: { USD?: { Value?: number } } };
    const rate = Number(data.Valute?.USD?.Value);
    if (rate > 10 && rate < 1000) return { rate, source: "cbr" };
  } catch (err) {
    console.warn("[currency] Курс ЦБ недоступен:", (err as Error).message);
  }
  const fb = Number(process.env.USD_RATE_FALLBACK || 90);
  return { rate: fb > 10 ? fb : 90, source: "fallback" };
}

/** Цена 1 шт. в долларах: PRICE_USD или PRODUCT.priceUsd */
export function unitPriceUsd(): number {
  const fixed = Number(process.env.PRICE_USD);
  return Number.isFinite(fixed) && fixed > 0 ? Math.round(fixed) : PRODUCT.priceUsd;
}

export interface UsdPrice {
  /** Цена 1 шт., $ */
  unit: number;
  /** Курс ₽ за $ */
  rate: number;
  source: UsdRate["source"];
}

export async function getUsdPrice(): Promise<UsdPrice> {
  const { rate, source } = await getUsdRate();
  return { unit: unitPriceUsd(), rate, source };
}

/**
 * Надбавка к стоимости доставки для заказов из-за рубежа, % — покрывает комиссию Robokassa
 * за карты зарубежных банков (9,9% со всей суммы; 11% возвращают её полностью). ABROAD_MARKUP_PERCENT.
 */
export function abroadMarkupPercent(): number {
  const v = Number(process.env.ABROAD_MARKUP_PERCENT ?? 11);
  return Number.isFinite(v) && v >= 0 && v < 100 ? v : 11;
}

/** Цены для заказов из-за рубежа: мел — в долларах, доставка — из рублей СДЭК с надбавкой; оплата — в рублях по курсу */
export interface AbroadPricing {
  unitUsd: number;
  rate: number;
  markupPercent: number;
}

export async function getAbroadPricing(): Promise<AbroadPricing> {
  const { unit, rate } = await getUsdPrice();
  return { unitUsd: unit, rate, markupPercent: abroadMarkupPercent() };
}

/** Доставка для покупателя из-за рубежа, целые $: цена СДЭК для покупателя (₽) + надбавка, по курсу, вверх */
export const deliveryUsdFor = (deliveryRub: number, p: Pick<AbroadPricing, "rate" | "markupPercent">) =>
  deliveryRub > 0 ? Math.ceil((deliveryRub * (1 + p.markupPercent / 100)) / p.rate) : 0;

/** Доллары → рубли к оплате (по курсу, до рубля) */
export const usdToRub = (usd: number, rate: number) => Math.round(usd * rate);
