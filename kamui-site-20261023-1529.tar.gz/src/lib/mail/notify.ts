/**
 * Письма покупателю с сайта: отправка, защита от повторов и отметка в таблице заказов
 * (колонка «Письма покупателю»: «оплата 23.10.2026 14:30», «трек 1234567890 23.10.2026 18:02», «хранение …»).
 */
import { SELLER } from "@/config/site";
import { updateOrder } from "@/lib/orders/store";
import { sendSmtp, smtpConfig } from "./smtp";
import { paidMail, storageMail, trackMail, type Mail, type MailOrder } from "./templates";

export type { MailOrder } from "./templates";

/** Письма включены: в настройках есть ящик и пароль (SMTP_USER / SMTP_PASSWORD) */
export const mailEnabled = () => smtpConfig() !== null;

export const validEmail = (s: string) => /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]{2,}$/.test(String(s || "").trim());

/** Что уже отправлено, пока сервер работает (после перезапуска — по отметкам в таблице) */
const sent = new Set<string>();

const nowMsk = () =>
  new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "");

const ddmm = (d: Date) => d.toLocaleDateString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "2-digit" });

/** Отправляет письмо (один раз на key) и дописывает отметку в таблицу. true — письмо ушло. */
async function deliver(o: MailOrder, mail: Mail, key: string, note: string): Promise<boolean> {
  const cfg = smtpConfig();
  if (!cfg || !validEmail(o.email) || sent.has(key)) return false;
  sent.add(key);
  try {
    await sendSmtp(cfg, {
      from: { name: process.env.MAIL_FROM_NAME?.trim() || "Abramov Shop", address: process.env.MAIL_FROM?.trim() || cfg.user },
      to: o.email.trim(),
      replyTo: SELLER.email || undefined,
      ...mail,
    });
  } catch (err) {
    sent.delete(key);
    console.error(`[mail] Письмо «${note}» по заказу ${o.id} не отправлено:`, (err as Error).message);
    throw err;
  }
  await updateOrder(o.id, { mailNote: `${note} ${nowMsk()}` });
  return true;
}

/** «Спасибо за заказ, оплата получена» */
export const notifyPaid = (o: MailOrder) => deliver(o, paidMail(o), `${o.id}:paid`, "оплата");

/** Трек-номер СДЭК со ссылкой для отслеживания */
export const notifyTrack = (o: MailOrder, track: string) => deliver(o, trackMail(o, track), `${o.id}:track:${track}`, `трек ${track}`);

/** Посылка в пункте выдачи — срок хранения заканчивается */
export const notifyStorage = (o: MailOrder, track: string, until: Date, manual = false) =>
  deliver(
    o,
    storageMail(o, track, until),
    // вручную со страницы накладных — можно отправить ещё раз (например, за день до конца хранения)
    manual ? `${o.id}:storage:${track}:${Date.now()}` : `${o.id}:storage:${track}`,
    `хранение ${track} до ${ddmm(until)}${manual ? " (вручную)" : ""}`,
  );

/** Письмо без исключений наружу — для after(): ошибка уже записана в журнал сервера */
export async function quietly(p: Promise<boolean>): Promise<void> {
  try {
    await p;
  } catch {
    /* см. журнал сервера */
  }
}
