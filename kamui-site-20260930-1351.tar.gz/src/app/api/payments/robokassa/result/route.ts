/**
 * Result URL Robokassa — уведомление об успешной оплате (сервер Robokassa → сайт).
 * Укажите в личном кабинете Robokassa: Мои магазины → Технические настройки →
 *   Result URL: https://kamui-collection.ru/api/payments/robokassa/result, метод POST.
 *
 * Подпись проверяется паролем №2. Ответ «OK<номер счёта>» — Robokassa перестаёт повторять уведомление.
 * После ответа: заказ в таблице → «Оплачена», создаётся накладная СДЭК (повторное уведомление дубль не создаст).
 */
import { revalidatePath } from "next/cache";
import { after } from "next/server";
import { features } from "@/config/features";
import { shipOrder } from "@/lib/delivery/ship";
import { ORDER_ID_RE } from "@/lib/orders/id";
import { updateOrderStrict } from "@/lib/orders/store";
import { readParams, robokassaPaymentLabel, verifyResult } from "@/lib/payments/robokassa";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const text = (body: string, status = 200) =>
  new Response(body, { status, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });

async function handle(request: Request): Promise<Response> {
  if (!features.robokassa) return text("robokassa is not configured", 404);
  const params = await readParams(request);
  const cb = verifyResult(params);
  if (!cb) {
    console.error("[robokassa] Неверная подпись уведомления, счёт", params.InvId ?? "?");
    return text("bad sign", 400);
  }
  if (!ORDER_ID_RE.test(cb.orderId)) {
    // Платёж не с этого сайта (например, счёт, выставленный вручную в личном кабинете)
    return text(`OK${cb.invoiceId}`);
  }

  let saved = true;
  try {
    await updateOrderStrict(cb.orderId, {
      status: "paid",
      payment: {
        provider: "robokassa",
        paymentId: `rk-${cb.invoiceId}`,
        status: "succeeded",
        paidAt: new Date().toISOString(),
        test: cb.test || undefined,
        label: robokassaPaymentLabel(cb),
      },
      ...(cb.test && cb.meta?.pvz
        ? {
            delivery: {
              provider: "cdek" as const,
              label: `${cb.meta.delivery || `СДЭК ПВЗ ${cb.meta.pvz}`} · тестовая оплата, накладная не создавалась`,
            },
          }
        : {}),
    });
  } catch (err) {
    // Таблица не ответила — накладную всё равно создаём, а Robokassa просим повторить уведомление позже
    console.error(`[robokassa] Не удалось отметить оплату ${cb.orderId}:`, err);
    saved = false;
  }

  if (!cb.test) {
    try {
      revalidatePath("/");
      revalidatePath("/en");
    } catch {
      /* страница обновится сама */
    }
    if (features.cdek && features.cdekAutoShipment && cb.meta?.pvz) {
      const meta = cb.meta;
      after(() => shipOrder({ ...meta, orderId: cb.orderId }));
    }
  }
  return saved ? text(`OK${cb.invoiceId}`) : text("retry later", 500);
}

export const POST = handle;
export const GET = handle;
