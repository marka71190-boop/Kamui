/**
 * /cdek-orders?token=<PAYMENTS_TEST_TOKEN> — служебная страница для продавца:
 * оплаченные заказы сайта и их накладные СДЭК.
 *
 * Если у оплаченного заказа нет накладной (сервер перезапустился в момент оплаты, СДЭК был недоступен
 * или не принял данные) — кнопка «Создать накладную». Если СДЭК отказал, видна причина.
 * Без правильного токена отвечает 404. В поиск не попадает.
 */
import { features } from "@/config/features";
import { CdekOrderRejected, findShipment, getTrackingNumber } from "@/lib/delivery/cdek";
import { shipPaidOrder, type ShipResult } from "@/lib/delivery/ship";
import { listPaidSiteOrders, type YooKassaPayment } from "@/lib/payments/yookassa";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = {
  "Content-Type": "text/html; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Robots-Tag": "noindex, nofollow",
  "Referrer-Policy": "no-referrer",
};

const notFound = () => new Response("Not found", { status: 404, headers: { "X-Robots-Tag": "noindex" } });

function authorized(given: string | null | undefined): boolean {
  const token = process.env.PAYMENTS_TEST_TOKEN ?? "";
  return token.length >= 8 && given === token;
}

type CdekState =
  | { kind: "ok"; number: string | null; status?: string }
  | { kind: "none" }
  | { kind: "rejected"; reason: string }
  | { kind: "error"; reason: string };

async function cdekState(orderId: string): Promise<CdekState> {
  try {
    const s = await findShipment(orderId);
    if (!s) return { kind: "none" };
    if (s.trackingNumber) return { kind: "ok", number: s.trackingNumber, status: s.status };
    try {
      return { kind: "ok", number: await getTrackingNumber(s.uuid), status: s.status };
    } catch (err) {
      if (err instanceof CdekOrderRejected) return { kind: "rejected", reason: err.message };
      throw err;
    }
  } catch (err) {
    return { kind: "error", reason: String((err as Error).message).slice(0, 200) };
  }
}

/** Проверяем накладные небольшими пачками, чтобы не упереться в лимиты СДЭК */
async function statesFor(payments: YooKassaPayment[]): Promise<CdekState[]> {
  const out: CdekState[] = [];
  for (let i = 0; i < payments.length; i += 6) {
    out.push(...(await Promise.all(payments.slice(i, i + 6).map((p) => cdekState(p.metadata?.orderId ?? "")))));
  }
  return out;
}

const esc = (v: unknown) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

const when = (p: YooKassaPayment) =>
  new Date(p.captured_at ?? p.created_at).toLocaleString("ru-RU", {
    timeZone: "Europe/Moscow",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });

const rub = (v: string) => `${Math.round(Number(v)).toLocaleString("ru-RU")} ₽`;

function button(token: string, orderId: string, label: string) {
  return `<form method="post"><input type="hidden" name="token" value="${esc(token)}"><input type="hidden" name="order" value="${esc(orderId)}"><button type="submit">${esc(label)}</button></form>`;
}

function card(p: YooKassaPayment, s: CdekState, token: string): string {
  const m = p.metadata ?? {};
  const id = m.orderId ?? "";
  let cdek: string;
  let cls: string;
  if (!m.pvz) {
    cls = "warn";
    cdek = "Заказ без пункта выдачи СДЭК — отправку оформляет менеджер";
  } else if (s.kind === "ok") {
    cls = "ok";
    cdek = `✓ Накладная СДЭК${s.number ? ` № ${esc(s.number)}` : " создана, номер ещё присваивается"}${s.status ? ` · ${esc(s.status)}` : ""}`;
  } else if (s.kind === "none") {
    cls = "bad";
    cdek = `⚠ Накладной нет${button(token, id, "Создать накладную")}`;
  } else if (s.kind === "rejected") {
    cls = "bad";
    cdek = `✕ ${esc(s.reason)}${button(token, id, "Создать заново")}`;
  } else {
    cls = "warn";
    cdek = `Не удалось проверить в СДЭК: ${esc(s.reason)}`;
  }
  return `<article class="${cls}">
  <header><b>${esc(id)}</b><span>${esc(when(p))} · ${esc(rub(p.amount.value))}</span></header>
  <p class="who">${esc(m.name)} · ${esc(m.phone)} · ${esc(m.qty)} шт.</p>
  ${m.delivery ? `<p class="dim">${esc(m.delivery)}</p>` : ""}
  <div class="cdek">${cdek}</div>
</article>`;
}

function page(body: string): Response {
  return new Response(
    `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>Накладные СДЭК</title>
<style>
:root{color-scheme:light dark;--bg:#f6f6f7;--card:#fff;--line:#e3e3e6;--dim:#6b6b73;--ok:#1d8a4e;--bad:#c62828;--warn:#9a6a00}
@media (prefers-color-scheme:dark){:root{--bg:#111113;--card:#1b1b1e;--line:#2c2c31;--dim:#9a9aa3;--ok:#4cc38a;--bad:#ff6b6f;--warn:#e3b341}}
*{box-sizing:border-box}body{margin:0;padding:16px;background:var(--bg);font:15px/1.45 -apple-system,system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:720px;margin:0 auto}h1{font-size:22px;margin:4px 0 6px}.lead{color:var(--dim);margin:0 0 16px}
.msg{padding:12px 14px;border-radius:10px;margin:0 0 16px;font-weight:600}.msg.ok{background:rgba(29,138,78,.12);color:var(--ok)}.msg.bad{background:rgba(198,40,40,.12);color:var(--bad)}
article{background:var(--card);border:1px solid var(--line);border-left-width:4px;border-radius:10px;padding:12px 14px;margin:0 0 10px}
article.ok{border-left-color:var(--ok)}article.bad{border-left-color:var(--bad)}article.warn{border-left-color:var(--warn)}
header{display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px 12px}header span{color:var(--dim)}
p{margin:6px 0 0}.dim{color:var(--dim);font-size:13px}.cdek{margin-top:8px;font-weight:600}
.ok .cdek{color:var(--ok)}.bad .cdek{color:var(--bad)}.warn .cdek{color:var(--warn)}
form{display:inline}button{margin:8px 0 0;display:block;padding:10px 16px;border:0;border-radius:8px;background:#e3161b;color:#fff;font:inherit;font-weight:700}
nav{margin:18px 0 0;color:var(--dim);font-size:13px}nav a{color:inherit}
</style></head><body><main>${body}</main></body></html>`,
    { status: 200, headers: HEADERS },
  );
}

async function render(token: string, days: number, message?: { ok: boolean; text: string }): Promise<Response> {
  if (!features.payments || !features.cdek) return page("<h1>Накладные СДЭК</h1><p>ЮKassa или СДЭК не подключены на сервере.</p>");
  let payments: YooKassaPayment[];
  try {
    payments = await listPaidSiteOrders(days);
  } catch (err) {
    return page(`<h1>Накладные СДЭК</h1><p class="msg bad">Не удалось получить платежи из ЮKassa: ${esc((err as Error).message)}</p>`);
  }
  const states = await statesFor(payments);
  const missing = payments.filter((p, i) => p.metadata?.pvz && (states[i].kind === "none" || states[i].kind === "rejected")).length;
  const cards = payments.map((p, i) => card(p, states[i], token)).join("\n");
  return page(`<h1>Накладные СДЭК</h1>
<p class="lead">Оплаченные заказы сайта за ${days} дн.: ${payments.length}. Без накладной: <b>${missing}</b>.</p>
${message ? `<p class="msg ${message.ok ? "ok" : "bad"}">${esc(message.text)}</p>` : ""}
${cards || "<p>Оплаченных заказов пока нет.</p>"}
<nav>Показаны последние ${days} дн. · <a href="?token=${esc(encodeURIComponent(token))}&days=${days === 14 ? 45 : 14}">показать за ${days === 14 ? 45 : 14} дн.</a></nav>`);
}

const daysFrom = (v: string | null) => Math.min(60, Math.max(1, Number.parseInt(v ?? "", 10) || 14));

export async function GET(request: Request) {
  const q = new URL(request.url).searchParams;
  const token = q.get("token");
  if (!authorized(token)) return notFound();
  return render(token!, daysFrom(q.get("days")));
}

export async function POST(request: Request) {
  const form = await request.formData().catch(() => null);
  const token = String(form?.get("token") ?? "");
  if (!authorized(token)) return notFound();
  const orderId = String(form?.get("order") ?? "");
  const days = 45;
  const payment = (await listPaidSiteOrders(days).catch(() => [] as YooKassaPayment[])).find(
    (p) => p.metadata?.orderId === orderId,
  );
  let result: ShipResult;
  if (!payment) result = { ok: false, error: `Оплаченный заказ ${orderId} не найден в ЮKassa` };
  else result = await shipPaidOrder(payment, { retryRejected: true });
  const text = result.ok
    ? `${orderId}: ${result.existed ? "накладная уже была" : "накладная создана"}${result.trackingNumber ? ` — № ${result.trackingNumber}` : ""}. В таблице обновлена колонка «Доставка».`
    : `${orderId}: СДЭК не создал накладную — ${result.error}`;
  return render(token, days, { ok: result.ok, text });
}
