/**
 * Kamui Collection — письма покупателям:
 *   • «Спасибо за заказ» — сразу после оплаты (при включённой автоотправке, по новым заказам);
 *   • трек-номер СДЭК со ссылкой для отслеживания — как только номер появится в таблице.
 *
 * Это ОТДЕЛЬНЫЙ файл в том же проекте Apps Script, что и основной скрипт таблицы заказов (apps-script.gs).
 * Основной код и SECRET не меняются, развёртывание веб-приложения обновлять не нужно.
 *
 * Установка (подробно — README.md, раздел «Письма с трек-номером»):
 *   1. В таблице заказов: Расширения → Apps Script.
 *   2. Слева у «Файлы» нажмите «+» → «Скрипт», назовите «Письма покупателям», вставьте этот код и сохраните.
 *   3. Обновите страницу таблицы — появится меню «Письма покупателям».
 *
 * Трек-номер берётся из колонки «Доставка»: сайт пишет туда «СДЭК ПВЗ … · трек 1234567890».
 * Если отправление оформлено вручную, впишите в «Доставка» «трек 1234567890» — письмо уйдёт так же.
 * В колонку «Письмо с треком» (создаётся сама) скрипт пишет, когда и с каким номером ушло письмо,
 * поэтому повторно на тот же номер покупатель письмо не получит.
 */

const TRACK_SHEET_NAME = "Заказы";
const TRACK_MARK_HEADER = "Письмо с треком";
/** Имя отправителя в письме (адрес — тот Google-аккаунт, от которого работает скрипт) */
const TRACK_FROM_NAME = "Abramov Shop";
/**
 * С какого адреса отправлять. Письмо уйдёт с него, если этот адрес добавлен в Gmail того аккаунта,
 * которому принадлежит таблица: Gmail → Настройки → «Аккаунты и импорт» → «Отправлять письма как».
 * Пока не добавлен — письма уходят с адреса самого аккаунта (ответы всё равно придут на TRACK_REPLY_TO).
 */
const TRACK_FROM_ADDRESS = "shop@abramov.shop";
/** Куда придёт ответ покупателя на письмо */
const TRACK_REPLY_TO = "shop@abramov.shop";
const TRACK_SITE_URL = "https://kamui-collection.ru";
const TRACK_SELLER = "ИП Абрамова Алина Гургеновна";
/** По заказам с этими статусами письма не отправляются */
const TRACK_SKIP_STATUSES = ["Оплата отменена", "Отменена", "Доставлена"];
/** Как часто автоотправка проверяет новые трек-номера, минут (1, 5, 10, 15 или 30) */
const TRACK_AUTO_MINUTES = 10;
/** Лист и колонка отметок для писем «Спасибо за заказ» */
const ORDER_MAIL_HEADER = "Письмо о заказе";
/** Через сколько после оплаты передаём посылку в СДЭК (как на сайте) */
const ORDER_DISPATCH_TIME = "1–3 рабочих дней";

/** Ссылка на отслеживание посылки на сайте СДЭК */
function trackLink_(number) {
  return "https://www.cdek.ru/ru/tracking/?order_id=" + encodeURIComponent(number);
}

/** Меню «Письма покупателям» в таблице */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("Письма покупателям")
    .addItem("Кому уйдут письма с трек-номером", "trackPreview")
    .addItem("Пробное письмо с трек-номером себе", "trackSendTest")
    .addItem("Пробное письмо «Спасибо за заказ» себе", "orderMailSendTest")
    .addSeparator()
    .addItem("Отправить трек-номера покупателям", "trackSendNow")
    .addSeparator()
    .addItem("Включить автоотправку", "trackEnableAuto")
    .addItem("Выключить автоотправку", "trackDisableAuto")
    .addToUi();
}

// ───────────── пункты меню ─────────────

/** Показывает, кому и с каким номером уйдут письма (ничего не отправляет) */
function trackPreview() {
  const ui = SpreadsheetApp.getUi();
  const all = trackCollect_().rows;
  const pending = all.filter(function (r) {
    return !r.sent && !r.skip;
  });
  const lines = [];
  lines.push(pending.length ? "Письма уйдут (" + pending.length + "):" : "Новых писем нет — всем, у кого есть трек-номер, письмо уже отправлено.");
  pending.slice(0, 40).forEach(function (r) {
    lines.push("• " + r.id + " · " + r.email + " · трек " + r.track);
  });
  if (pending.length > 40) lines.push("… и ещё " + (pending.length - 40));
  const skipped = all.filter(function (r) {
    return r.skip;
  });
  if (skipped.length) {
    lines.push("", "Не отправляем (" + skipped.length + "):");
    skipped.slice(0, 20).forEach(function (r) {
      lines.push("• " + r.id + " — " + r.skip);
    });
  }
  const sent = all.length - pending.length - skipped.length;
  if (sent) lines.push("", "Уже отправлено раньше: " + sent);
  lines.push("", "Отправитель: " + trackSenderText_());
  lines.push("Можно отправить сегодня: " + MailApp.getRemainingDailyQuota() + " писем (дневной лимит Google).");
  ui.alert("Письма с трек-номером", lines.join("\n"), ui.ButtonSet.OK);
}

/** Пробное письмо на свою почту — посмотреть, как его увидит покупатель. Покупателю ничего не уходит. */
function trackSendTest() {
  const ui = SpreadsheetApp.getUi();
  const all = trackCollect_().rows;
  const pending = all.filter(function (r) {
    return !r.sent && !r.skip;
  });
  const sample = pending[0] ||
    all[0] || {
      id: "KA-000000-TEST",
      name: "Иван",
      qty: "1",
      comment: "",
      delivery: "СДЭК ПВЗ KRD12 · Краснодар, ул. Красная, 1",
      track: "1234567890",
    };
  const me = Session.getEffectiveUser().getEmail();
  trackSendMail_(sample, me, true);
  ui.alert(
    "Пробное письмо",
    "Письмо по заказу " + sample.id + " отправлено на " + me + ".\nОтправитель: " + trackSenderText_() + ".\nПокупателю ничего не ушло.\n\nПроверьте в письме кнопку «Отследить посылку».",
    ui.ButtonSet.OK,
  );
}

/** Отправляет письма всем, у кого есть трек-номер и кому письмо ещё не уходило */
function trackSendNow() {
  const ui = SpreadsheetApp.getUi();
  const pending = trackCollect_().rows.filter(function (r) {
    return !r.sent && !r.skip;
  });
  if (!pending.length) {
    ui.alert("Письма с трек-номером", "Новых писем нет — всем, у кого есть трек-номер, письмо уже отправлено.", ui.ButtonSet.OK);
    return;
  }
  const answer = ui.alert(
    "Письма с трек-номером",
    "Отправить письма с трек-номером " + pending.length + " покупателям?\n(Список — в пункте «Кому уйдут письма».)",
    ui.ButtonSet.YES_NO,
  );
  if (answer !== ui.Button.YES) return;
  const res = trackSendPending_();
  ui.alert("Письма с трек-номером", trackReport_(res), ui.ButtonSet.OK);
}

/** Автоотправка: раз в TRACK_AUTO_MINUTES минут письма уходят по новым трек-номерам */
function trackEnableAuto() {
  trackRemoveTriggers_();
  orderMailSince_(); // письма «Спасибо за заказ» — только по заказам с этого момента
  ScriptApp.newTrigger("trackAuto").timeBased().everyMinutes(TRACK_AUTO_MINUTES).create();
  const pending = trackCollect_().rows.filter(function (r) {
    return !r.sent && !r.skip;
  }).length;
  SpreadsheetApp.getUi().alert(
    "Автоотправка включена",
    "Раз в " + TRACK_AUTO_MINUTES + " минут скрипт проверяет таблицу и отправляет покупателю письма:\n• «Спасибо за заказ» — после оплаты (по новым заказам);\n• трек-номер — как только он появляется у заказа." +
      (pending ? "\n\nСейчас ждут отправки: " + pending + " — уйдут при ближайшей проверке." : ""),
    SpreadsheetApp.getUi().ButtonSet.OK,
  );
}

function trackDisableAuto() {
  const n = trackRemoveTriggers_();
  SpreadsheetApp.getUi().alert("Автоотправка", n ? "Автоотправка выключена." : "Автоотправка и так была выключена.", SpreadsheetApp.getUi().ButtonSet.OK);
}

/** Запускается по расписанию (см. trackEnableAuto) */
function trackAuto() {
  const ord = orderMailSendPending_();
  if (ord.sent || ord.failed.length) console.log("Письма о заказе: " + trackReport_(ord));
  const res = trackSendPending_();
  if (res.sent || res.failed.length) console.log("Трек-номера: " + trackReport_(res));
}

// ───────────── письмо «Спасибо за заказ» после оплаты ─────────────

/**
 * С какого момента писать «Спасибо за заказ»: запоминается при первом включении автоотправки,
 * чтобы старые заказы не получили письмо задним числом.
 */
function orderMailSince_() {
  const props = PropertiesService.getScriptProperties();
  let since = Number(props.getProperty("ORDER_MAIL_SINCE"));
  if (!since) {
    since = Date.now();
    props.setProperty("ORDER_MAIL_SINCE", String(since));
  }
  return since;
}

/** «22.10.2026 18:30» → время в мс (часовой пояс таблицы — Москва) */
function orderDate_(s) {
  const m = /^(\d{2})\.(\d{2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/.exec(String(s || "").trim());
  if (!m) return 0;
  return Date.UTC(Number(m[3]), Number(m[2]) - 1, Number(m[1]), Number(m[4] || 0) - 3, Number(m[5] || 0));
}

/** Оплаченные новые заказы, которым ещё не писали «Спасибо за заказ» */
function orderMailCollect_() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TRACK_SHEET_NAME);
  if (!sh || sh.getLastRow() < 2) return { sh: sh, rows: [] };
  const since = orderMailSince_();
  const lastCol = sh.getLastColumn();
  const head = sh
    .getRange(1, 1, 1, lastCol)
    .getDisplayValues()[0]
    .map(function (h) {
      return String(h).trim();
    });
  const ix = function (name) {
    return head.indexOf(name);
  };
  const c = { id: trackIdColumn_(sh, head), date: ix("Дата"), status: ix("Статус"), name: ix("Имя"), email: ix("Email"), qty: ix("Количество"), total: ix("Сумма"), delivery: ix("Доставка"), comment: ix("Комментарий"), mark: ix(ORDER_MAIL_HEADER) };
  if (c.id < 0 || c.email < 0 || c.status < 0 || c.date < 0) return { sh: sh, rows: [] };
  const cell = function (v, i) {
    return i >= 0 ? String(v[i]).trim() : "";
  };
  const rows = [];
  sh.getRange(2, 1, sh.getLastRow() - 1, lastCol)
    .getDisplayValues()
    .forEach(function (v, i) {
      if (cell(v, c.status) !== "Оплачена") return;
      if (cell(v, c.mark)) return;
      // заказ оформлен раньше, чем включили письма, — не пишем (с запасом в сутки на оплату позже оформления)
      if (orderDate_(cell(v, c.date)) < since - 24 * 3600 * 1000) return;
      const email = cell(v, c.email);
      if (!trackValidEmail_(email)) return;
      rows.push({ row: i + 2, id: cell(v, c.id), name: cell(v, c.name), email: email, qty: cell(v, c.qty), total: cell(v, c.total), delivery: cell(v, c.delivery), comment: cell(v, c.comment) });
    });
  return { sh: sh, rows: rows };
}

function orderMailSendPending_() {
  const lock = LockService.getDocumentLock();
  if (!lock.tryLock(10000)) return { sent: 0, failed: [], left: 0, busy: true };
  try {
    const data = orderMailCollect_();
    const res = { sent: 0, failed: [], left: 0 };
    if (!data.rows.length) return res;
    const col = trackEnsureColumn_(data.sh, ORDER_MAIL_HEADER);
    for (let i = 0; i < data.rows.length; i++) {
      const r = data.rows[i];
      if (MailApp.getRemainingDailyQuota() < 1) {
        res.left = data.rows.length - i;
        break;
      }
      const mark = data.sh.getRange(r.row, col).setNumberFormat("@");
      try {
        orderMailSend_(r, r.email, false);
        mark.setValue("отправлено " + trackNow_());
        res.sent++;
      } catch (err) {
        const msg = String((err && err.message) || err).slice(0, 150);
        // отметка с ошибкой не даёт слать повторно каждые 10 минут; сотрите её, чтобы попробовать снова
        mark.setValue("ошибка " + trackNow_() + ": " + msg);
        res.failed.push(r.id + ": " + msg);
      }
    }
    SpreadsheetApp.flush();
    return res;
  } finally {
    lock.releaseLock();
  }
}

function orderMailSend_(r, to, test) {
  trackDeliver_({
    to: to,
    subject: (test ? "[Пробное] " : "") + "Спасибо за заказ " + r.id + "! Оплата получена",
    body: orderMailText_(r),
    htmlBody: orderMailHtml_(r),
    name: TRACK_FROM_NAME,
    replyTo: TRACK_REPLY_TO,
  });
}

/** Пробное письмо «Спасибо за заказ» на свою почту */
function orderMailSendTest() {
  const me = Session.getEffectiveUser().getEmail();
  const sample = {
    id: "KA-000000-TEST",
    name: "Иван",
    qty: "1",
    total: "3 955 ₽",
    comment: "",
    delivery: "СДЭК ПВЗ KRD12 · Краснодар, ул. Красная, 1 · 455 ₽",
  };
  orderMailSend_(sample, me, true);
  SpreadsheetApp.getUi().alert("Пробное письмо", "Письмо «Спасибо за заказ» (с примером заказа) отправлено на " + me + ".", SpreadsheetApp.getUi().ButtonSet.OK);
}

function orderMailText_(r) {
  const pickup = trackPickupFrom_(r.delivery);
  return [
    trackGreeting_(r),
    "",
    "Спасибо за заказ! Оплата заказа " + r.id + " получена.",
    trackItemsFrom_(r),
    r.total ? "Сумма: " + r.total : "",
    pickup ? "Пункт выдачи СДЭК: " + pickup : "",
    "",
    "Мы передадим посылку в СДЭК в течение " + ORDER_DISPATCH_TIME + " и пришлём трек-номер отдельным письмом.",
    "Кассовый чек приходит на эту почту от платёжного сервиса.",
    "",
    "Если есть вопросы по заказу — просто ответьте на это письмо.",
    "",
    "Abramov Shop — официальный магазин мела Kamui × Iosif Abramov",
    TRACK_SITE_URL.replace(/^https:\/\//, ""),
    TRACK_SELLER,
  ]
    .filter(function (line, i, a) {
      return line !== "" || (i > 0 && a[i - 1] !== "");
    })
    .join("\n");
}

function orderMailHtml_(r) {
  const e = trackEsc_;
  const pickup = trackPickupFrom_(r.delivery);
  const row = function (label, value) {
    return value
      ? '<tr><td style="padding:6px 0;color:#777;font-size:14px;width:120px;vertical-align:top">' + e(label) + '</td><td style="padding:6px 0;font-size:14px;color:#141414">' + e(value) + "</td></tr>"
      : "";
  };
  const body =
    '<p style="margin:0 0 14px">' + e(trackGreeting_(r)) + "</p>" +
    '<p style="margin:0 0 6px;font-size:22px;font-weight:bold">Спасибо за заказ!</p>' +
    '<p style="margin:0 0 16px">Оплата заказа <b>' + e(r.id) + "</b> получена.</p>" +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #ececee;border-bottom:1px solid #ececee;margin:0 0 16px">' +
    row("Заказ", trackItemsFrom_(r)) +
    row("Сумма", r.total) +
    row("Пункт выдачи", pickup ? "СДЭК, " + pickup : "") +
    "</table>" +
    '<p style="margin:0 0 10px;font-size:15px">Мы передадим посылку в СДЭК в течение <span style="white-space:nowrap">' + e(ORDER_DISPATCH_TIME) + "</span> и пришлём трек-номер отдельным письмом.</p>" +
    '<p style="margin:0 0 10px;font-size:14px;color:#555">Кассовый чек приходит на эту почту от платёжного сервиса.</p>' +
    '<p style="margin:0;font-size:14px;color:#555">Если есть вопросы по заказу — просто ответьте на это письмо.</p>';
  return trackFrame_(body);
}

// ───────────── работа с таблицей ─────────────

/** Все заказы с трек-номером: кому уже писали, кому нельзя и почему */
function trackCollect_() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TRACK_SHEET_NAME);
  if (!sh || sh.getLastRow() < 2) return { sh: sh, rows: [] };
  const lastCol = sh.getLastColumn();
  const head = sh
    .getRange(1, 1, 1, lastCol)
    .getDisplayValues()[0]
    .map(function (h) {
      return String(h).trim();
    });
  const c = {
    id: trackIdColumn_(sh, head),
    status: head.indexOf("Статус"),
    name: head.indexOf("Имя"),
    email: head.indexOf("Email"),
    qty: head.indexOf("Количество"),
    delivery: head.indexOf("Доставка"),
    comment: head.indexOf("Комментарий"),
    mark: head.indexOf(TRACK_MARK_HEADER),
  };
  if (c.id < 0 || c.email < 0 || c.delivery < 0) {
    throw new Error("На листе «" + TRACK_SHEET_NAME + "» не найдены колонки: " + [c.id < 0 ? "номер заказа (KA-…)" : "", c.email < 0 ? "«Email»" : "", c.delivery < 0 ? "«Доставка»" : ""].filter(String).join(", ") + ". Проверьте заголовки в первой строке.");
  }
  const cell = function (v, i) {
    return i >= 0 ? String(v[i]).trim() : "";
  };
  const values = sh.getRange(2, 1, sh.getLastRow() - 1, lastCol).getDisplayValues();
  const rows = [];
  values.forEach(function (v, i) {
    const track = trackNumberFrom_(cell(v, c.delivery));
    if (!track) return;
    const r = {
      row: i + 2,
      id: cell(v, c.id),
      status: cell(v, c.status),
      name: cell(v, c.name),
      email: cell(v, c.email),
      qty: cell(v, c.qty),
      delivery: cell(v, c.delivery),
      comment: cell(v, c.comment),
      track: track,
    };
    // уже писали с этим номером (если номер сменился — напишем заново)
    r.sent = cell(v, c.mark).indexOf("отправлено") === 0 && cell(v, c.mark).indexOf(track) >= 0;
    r.skip = !trackValidEmail_(r.email)
      ? "нет почты или почта с ошибкой («" + r.email + "»)"
      : TRACK_SKIP_STATUSES.indexOf(r.status) >= 0
        ? "статус «" + r.status + "»"
        : "";
    rows.push(r);
  });
  return { sh: sh, rows: rows };
}

/**
 * Колонка с номером заказа. Обычно её заголовок — «ID заказа», но если лист превратили в «Таблицу» Google,
 * заголовок мог смениться на «Столбец 1» — тогда ищем колонку, где лежат номера вида KA-261022-QUJE.
 */
function trackIdColumn_(sh, head) {
  const byName = head.indexOf("ID заказа");
  if (byName >= 0) return byName;
  const rows = Math.min(20, sh.getLastRow() - 1);
  if (rows < 1) return -1;
  const sample = sh.getRange(2, 1, rows, head.length).getDisplayValues();
  for (let col = 0; col < head.length; col++) {
    const hits = sample.filter(function (v) {
      return /^KA-\d{6}-[A-Z0-9]{4}$/.test(String(v[col]).trim());
    }).length;
    if (hits > 0 && hits >= rows / 2) return col;
  }
  return -1;
}

/** Отправляет все ждущие письма и отмечает их в колонке «Письмо с треком» */
function trackSendPending_() {
  // Отдельная блокировка документа: приём заказов с сайта (блокировка скрипта) не ждёт, пока идёт рассылка
  const lock = LockService.getDocumentLock();
  if (!lock.tryLock(10000)) return { sent: 0, failed: [], left: 0, busy: true };
  try {
    const data = trackCollect_();
    const pending = data.rows.filter(function (r) {
      return !r.sent && !r.skip;
    });
    const res = { sent: 0, failed: [], left: 0 };
    if (!pending.length) return res;
    const markCol = trackMarkColumn_(data.sh);
    for (let i = 0; i < pending.length; i++) {
      const r = pending[i];
      if (MailApp.getRemainingDailyQuota() < 1) {
        res.left = pending.length - i;
        break;
      }
      const mark = data.sh.getRange(r.row, markCol).setNumberFormat("@");
      try {
        trackSendMail_(r, r.email, false);
        mark.setValue("отправлено " + trackNow_() + " · трек " + r.track);
        res.sent++;
      } catch (err) {
        const msg = String((err && err.message) || err).slice(0, 150);
        mark.setValue("ошибка " + trackNow_() + ": " + msg);
        res.failed.push(r.id + ": " + msg);
      }
    }
    SpreadsheetApp.flush();
    return res;
  } finally {
    lock.releaseLock();
  }
}

/** Номер колонки «Письмо с треком»; если её нет — добавляет в конец */
function trackMarkColumn_(sh) {
  return trackEnsureColumn_(sh, TRACK_MARK_HEADER);
}

/** Номер колонки с заголовком header; если её нет — добавляет в конец */
function trackEnsureColumn_(sh, header) {
  const lastCol = sh.getLastColumn();
  const head = sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0];
  for (let i = 0; i < head.length; i++) if (String(head[i]).trim() === header) return i + 1;
  if (lastCol >= sh.getMaxColumns()) sh.insertColumnAfter(lastCol);
  const col = lastCol + 1;
  sh.getRange(1, col).setValue(header).setFontWeight("bold").setBackground("#111111").setFontColor("#ffffff");
  sh.setColumnWidth(col, 220);
  return col;
}

function trackRemoveTriggers_() {
  let n = 0;
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === "trackAuto") {
      ScriptApp.deleteTrigger(t);
      n++;
    }
  });
  return n;
}

function trackReport_(res) {
  if (res.busy) return "Сейчас уже идёт отправка — попробуйте через минуту.";
  const lines = ["Отправлено писем: " + res.sent + "."];
  if (res.failed.length) lines.push("", "Не отправлено (" + res.failed.length + "):", "• " + res.failed.join("\n• "));
  if (res.left) lines.push("", "Дневной лимит писем Google исчерпан. Осталось отправить: " + res.left + " — они уйдут завтра (с автоотправкой — сами).");
  return lines.join("\n");
}

// ───────────── письмо ─────────────

/** «… · трек 1234567890» → «1234567890» */
function trackNumberFrom_(delivery) {
  const m = /(?:трек|track)\s*(?:№|#|:)?\s*(\d{6,16})/i.exec(String(delivery || ""));
  return m ? m[1] : "";
}

/** Адрес пункта выдачи из колонки «Доставка»: «СДЭК ПВЗ KRD12 · Краснодар, ул. Красная, 1 · …» */
function trackPickupFrom_(delivery) {
  const parts = String(delivery || "").split(" · ");
  if (!/^СДЭК ПВЗ/.test(parts[0]) || !parts[1]) return "";
  return /₽|\$|трек|дн\.|⚠/.test(parts[1]) ? "" : parts[1];
}

/** Что в заказе: мел или подарочный набор (первая строка комментария — «Подарочный набор × 2 · наклейка JOS H+») */
function trackItemsFrom_(r) {
  const qty = Number(String(r.qty).replace(/\D/g, "")) || 1;
  const kit = /^Подарочный набор/.test(r.comment || "");
  if (kit) {
    const tip = /наклейка JOS\s+(\S+)/.exec(r.comment);
    return "Подарочный набор Kamui × Iosif Abramov" + (tip ? " (наклейка JOS " + tip[1] + ")" : "") + " — " + qty + " шт.";
  }
  return "Мел Kamui × Iosif Abramov 0.98 β — " + qty + " шт.";
}

function trackSendMail_(r, to, test) {
  trackDeliver_({
    to: to,
    subject: (test ? "[Пробное] " : "") + "Трек-номер СДЭК по заказу " + r.id + ": " + r.track,
    body: trackText_(r),
    htmlBody: trackHtml_(r),
    name: TRACK_FROM_NAME,
    replyTo: TRACK_REPLY_TO,
  });
}

function trackGreeting_(r) {
  return r.name ? "Здравствуйте, " + r.name + "!" : "Здравствуйте!";
}

function trackText_(r) {
  const pickup = trackPickupFrom_(r.delivery);
  return [
    trackGreeting_(r),
    "",
    "Ваш заказ " + r.id + " оформлен к отправке службой доставки СДЭК.",
    trackItemsFrom_(r),
    pickup ? "Пункт выдачи СДЭК: " + pickup : "",
    "",
    "Трек-номер: " + r.track,
    "Отследить посылку: " + trackLink_(r.track),
    "",
    "Статус в СДЭК обновится, когда посылка будет передана в службу доставки. Когда она прибудет в пункт выдачи, СДЭК пришлёт SMS.",
    "",
    "Если есть вопросы по заказу — просто ответьте на это письмо.",
    "",
    "Abramov Shop — официальный магазин мела Kamui × Iosif Abramov",
    TRACK_SITE_URL.replace(/^https:\/\//, ""),
    TRACK_SELLER,
  ]
    .filter(function (line, i, a) {
      // пустые строки подряд не нужны
      return line !== "" || (i > 0 && a[i - 1] !== "");
    })
    .join("\n");
}

function trackHtml_(r) {
  const e = trackEsc_;
  const pickup = trackPickupFrom_(r.delivery);
  const link = trackLink_(r.track);
  const body =
    '<p style="margin:0 0 14px">' + e(trackGreeting_(r)) + "</p>" +
    '<p style="margin:0 0 14px">Ваш заказ <b>' + e(r.id) + "</b> оформлен к отправке службой доставки СДЭК.</p>" +
    '<p style="margin:0 0 6px;color:#555;font-size:14px">' + e(trackItemsFrom_(r)) + "</p>" +
    (pickup ? '<p style="margin:0 0 6px;color:#555;font-size:14px">Пункт выдачи СДЭК: ' + e(pickup) + "</p>" : "") +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f6f6f7;border-radius:10px;margin:22px 0 16px"><tr><td style="padding:18px 20px">' +
    '<div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;color:#777">Трек-номер СДЭК</div>' +
    '<div style="margin-top:6px;font-size:28px;font-weight:bold;letter-spacing:2px;color:#141414">' + e(r.track) + "</div>" +
    "</td></tr></table>" +
    '<a href="' + e(link) + '" style="display:block;background:#e3161b;color:#ffffff;text-decoration:none;text-align:center;font-size:16px;font-weight:bold;padding:16px 20px;border-radius:8px">Отследить посылку</a>' +
    '<p style="margin:20px 0 10px;font-size:14px;color:#555">Статус в СДЭК обновится, когда посылка будет передана в службу доставки. Когда она прибудет в пункт выдачи, СДЭК пришлёт SMS.</p>' +
    '<p style="margin:0;font-size:14px;color:#555">Если есть вопросы по заказу — просто ответьте на это письмо.</p>';
  return trackFrame_(body);
}

/** Оформление письма: шапка, белая карточка, подвал с реквизитами */
function trackFrame_(inner) {
  const e = trackEsc_;
  const site = TRACK_SITE_URL.replace(/^https:\/\//, "");
  return (
    '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>' +
    '<body style="margin:0;padding:0;background:#f2f2f3">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f2f2f3"><tr><td align="center" style="padding:24px 12px">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;color:#141414">' +
    '<tr><td style="background:#111111;padding:18px 24px;color:#ffffff;font-size:15px;font-weight:bold;letter-spacing:1px">KAMUI <span style="color:#e3161b">×</span> IOSIF ABRAMOV</td></tr>' +
    '<tr><td style="padding:28px 24px 24px;font-size:16px;line-height:1.5">' + inner + "</td></tr>" +
    '<tr><td style="padding:16px 24px;border-top:1px solid #ececee;font-size:12px;line-height:1.5;color:#888">' +
    'Abramov Shop — официальный магазин мела Kamui × Iosif Abramov<br><a href="' + e(TRACK_SITE_URL) + '" style="color:#888">' + e(site) + "</a> · " + e(TRACK_SELLER) +
    "</td></tr>" +
    "</table></td></tr></table></body></html>"
  );
}

/** Подключён ли TRACK_FROM_ADDRESS в Gmail («Отправлять письма как») */
function trackFromAlias_() {
  if (!TRACK_FROM_ADDRESS) return "";
  try {
    const want = TRACK_FROM_ADDRESS.toLowerCase();
    return GmailApp.getAliases().some(function (a) {
      return String(a).toLowerCase() === want;
    })
      ? TRACK_FROM_ADDRESS
      : "";
  } catch (err) {
    return "";
  }
}

function trackSenderText_() {
  const own = Session.getEffectiveUser().getEmail();
  return trackFromAlias_()
    ? TRACK_FROM_ADDRESS
    : own + (TRACK_FROM_ADDRESS ? " (" + TRACK_FROM_ADDRESS + " пока не добавлен в Gmail в «Отправлять письма как»)" : "");
}

/** Отправка: с адреса магазина, если он подключён в Gmail, иначе — с адреса аккаунта */
function trackDeliver_(o) {
  const from = trackFromAlias_();
  if (from) {
    GmailApp.sendEmail(o.to, o.subject, o.body, { htmlBody: o.htmlBody, name: o.name, replyTo: o.replyTo, from: from });
  } else {
    MailApp.sendEmail(o);
  }
}

function trackValidEmail_(s) {
  return /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]{2,}$/.test(String(s || ""));
}

function trackNow_() {
  return Utilities.formatDate(new Date(), "Europe/Moscow", "dd.MM.yyyy HH:mm");
}

function trackEsc_(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (ch) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
  });
}
